# Netlify deployment checklist

## Preferred: Netlify Git import

- Extract the project ZIP.
- Commit the extracted project contents to the root of a Git repository.
- Import that repository in Netlify.
- Build command: `npm run build`.
- Publish directory: `dist`.
- Functions directory: `netlify/functions` (already declared in `netlify.toml`).
- Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as build environment variables.
- Set `OPENAI_API_KEY`, `SUPABASE_URL`, `SUPABASE_ANON_KEY` and optional `OPENAI_MODEL` as server-only environment variables for the authenticated AI function.
- Apply `supabase/schema.sql` and set the Supabase Auth Site URL / redirect allow-list.
- Rebuild after changing any `VITE_` variables.

## Manual deploy

Run `npm install` and `npm run build` on a local machine with build-time Supabase values configured. Upload the contents of `dist/` for a static deployment. Manual static upload does not package serverless functions; use the Git workflow or Netlify CLI for the AI route.

## Secrets

Never place Supabase service-role keys or OpenAI API keys in client-side code or `VITE_` variables. Only the Supabase publishable/anon key belongs in the browser bundle, protected by RLS. Keep private keys in Netlify's environment-variable settings.
