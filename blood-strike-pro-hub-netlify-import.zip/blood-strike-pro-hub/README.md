# BLOOD STRIKE PRO HUB

Premium, mobile-first community companion for **NETEASE Blood Strike Mobile**. Built with React, TypeScript, Vite, Tailwind CSS v4, Framer Motion, Supabase and Netlify Functions.

> This is an independent community project. It is not an official NetEase product and is not affiliated with or endorsed by NetEase. Game names and trademarks belong to their respective owners.

## What is included

### Works without a backend (browser-local)
- Six sensitivity layers: Camera, ADS, Firing, Gyroscope Camera, Gyroscope ADS and Gyroscope Firing.
- Eight scope rows per layer, with 6x/8x marked optional because availability can vary by game build.
- Editable 0–300 sliders, device profile, local history, JSON export/copy, reset, up to five local presets and two-preset comparison.
- Loadout drafts with editable weapon/attachment names, equipment, operator, playstyle and notes; local save, compare and JSON share.
- HUD layout planner for 2–5 fingers, preview size/opacity controls, local save and export. It does not inject settings into the game.
- Daily aim-training checklist, progress history and skill notes.
- Safe Android performance checklist and reversible troubleshooting guidance.

### Requires Supabase
- Email/password registration and login; profile username, favourite weapon notes and admin role.
- Verified-only weapon and operator catalogs.
- Database-published articles, media links and tournament records.
- Registration requests for tournaments that are in `registration_open` status.
- Community posts, likes, comments and user reports.
- Authenticated support tickets.
- Admin-only article publishing and protected database operations (additional bulk tools are done in the Supabase dashboard or can be added to a project-specific admin workflow).

### Requires the Netlify AI function and an OpenAI API key
- Blood Strike-focused assistant requests are sent to `/api/assistant`.
- AI use requires a signed-in Supabase player session, verified server-side against Supabase Auth.
- The OpenAI key is read only by the server-side Netlify Function. It is never placed in frontend code.
- Requests are size-limited and have a best-effort per-function-instance rate limit. Configure provider-side spending limits and monitor Netlify logs before public launch.

## Project structure

```text
blood-strike-pro-hub/
├── index.html
├── package.json
├── netlify.toml
├── vite.config.ts
├── tsconfig*.json
├── .env.example
├── public/
│   ├── _headers
│   ├── favicon.svg
│   ├── robots.txt
│   └── sitemap.xml
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   ├── styles.css
│   ├── types.ts
│   ├── components/
│   ├── data/defaults.ts
│   └── lib/
├── netlify/functions/assistant.ts
├── supabase/schema.sql
└── docs/
```

## 1. Run locally

Requirements: Node.js 20.19+ (or 22.12+) and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

For local development with the Netlify Vite plugin, the project also supports Netlify's local environment. If you prefer the Netlify CLI workflow, install the CLI and run `netlify dev` after linking the site.

## 2. Configure Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql` once.
3. Copy the project URL and the browser-safe publishable/anon key.
4. Put these values in `.env` for local development:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

5. In Supabase Auth settings, set the Site URL and allowed redirect URLs to your local and deployed domains. Choose the email confirmation policy you want.
6. Create the first account through the app. Then use the SQL Editor to promote that exact account to admin:

```sql
update public.profiles
set role = 'admin'
where id = 'YOUR_AUTH_USER_UUID';
```

Do not add a service-role or secret key to any `VITE_` variable or browser code. The schema blocks ordinary players from changing their role and uses RLS for protected operations.

### Publishing verified game information

Weapon and operator views intentionally show only rows where `verified = true`. The repository contains no invented weapon damage, fire rates, reload times, recoil ratings, operator abilities, event results or live rankings. Add sourced records through an admin workflow or the Supabase dashboard; fill `source_url` and `source_notes`, review the source, then mark the record verified. Empty fields render as `Not published` or `—`.

## 3. Configure the AI assistant

Set these as **server-side Netlify environment variables** (not browser variables):

```env
OPENAI_API_KEY=YOUR_OPENAI_API_KEY
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
OPENAI_MODEL=gpt-6-luna
```

The default model is `gpt-6-luna`; override it with a model available to your OpenAI project. The function uses the OpenAI Responses API with `store: false`. Never commit `.env`, paste an API key into the app, or use a `VITE_OPENAI_API_KEY` variable.

## 4. Deploy to Netlify (recommended: Git import)

The full app uses Vite and a serverless function. **Use Git-based deployment for the complete application and AI function.**

1. Extract this ZIP on your computer.
2. Create a new GitHub repository and upload the *contents* of the extracted project folder (the `package.json`, `src/`, `netlify.toml`, `netlify/` and `supabase/` items should be at the repository root).
3. In Netlify, choose **Add new project → Import an existing project** and connect that repository.
4. Netlify reads `netlify.toml`. Confirm build command `npm run build` and publish directory `dist`.
5. Add the environment variables listed above under **Site configuration → Environment variables**.
6. Deploy. After changing environment variables, trigger a new deploy so Vite can rebuild the client bundle.
7. Configure your Supabase Auth Site URL and redirect allow-list with the deployed Netlify domain.
8. Replace `YOUR_DOMAIN.example` in `public/robots.txt` and `public/sitemap.xml` with your real domain, then redeploy.

### Manual static upload

For a static-only manual deploy, first build locally with the correct `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`, then upload the generated `dist/` folder in Netlify's manual deploy UI. A static drag-and-drop deploy does **not** deploy the Netlify Function directory; use Git import or the Netlify CLI to deploy the AI function as well. Supabase client features can work in a static deploy when the build-time public keys are set.

## 5. Testing and release checklist

```bash
npm run typecheck
npm test
npm run build
npm run preview
```

Before public launch, also verify:
- Supabase Auth confirmation, password reset and redirect URLs.
- RLS policies using separate ordinary-player and admin accounts.
- Verified records and source links for every weapon/operator/media item.
- Tournament rules, registration limits, cancellation and result review procedures.
- Admin report moderation and data retention/backups.
- Netlify function rate limits, OpenAI usage limits and provider logs.
- Real-device mobile tests on small Android screens, slow networks and reduced-motion settings.
- Your actual privacy notice, terms, contact details and jurisdiction-specific disclosures.

See `docs/TESTING_REPORT.md` and `docs/DEPLOYMENT.md` for delivery notes.

## Important implementation boundaries

- Presets, loadouts, HUD drafts and training progress are local to the current browser in this starter. They are not silently synced to a cloud account.
- Tournament records are database-driven, but there is no automatic bracket engine, live match ingest or verified player ranking feed.
- Media items are outbound links to original creator/platform pages; files are not rehosted. An upload/storage workflow is not included.
- Community likes/comments/reports are database-backed. Moderation is performed by admins through protected records; automatic moderation is not included.
- The AI assistant is not a source of live game data. Verify all current game-specific details before publishing or changing settings.
- The site does not promise zero recoil, guaranteed FPS, zero ping or competitive results.
