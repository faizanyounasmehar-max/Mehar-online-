import type { SavedHud, SavedLoadout, SensitivityPreset, TrainingEntry } from '../types'

const PREFIX = 'bsph:v1:'

export function readStore<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export function writeStore<T>(key: string, value: T): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value))
  } catch (error) {
    console.error(`Could not save ${key} to local storage`, error)
    throw new Error('Browser storage is unavailable or full. Export your settings before continuing.')
  }
}

export function addPreset(preset: SensitivityPreset): SensitivityPreset[] {
  const current = readStore<SensitivityPreset[]>('sensitivity-presets', [])
  if (current.length >= 5) throw new Error('You can save up to five sensitivity presets. Delete one to make room.')
  const next = [preset, ...current]
  writeStore('sensitivity-presets', next)
  return next
}

export function addLoadout(loadout: SavedLoadout): SavedLoadout[] {
  const current = readStore<SavedLoadout[]>('loadouts', [])
  const next = [loadout, ...current]
  writeStore('loadouts', next)
  return next
}

export function addHud(hud: SavedHud): SavedHud[] {
  const current = readStore<SavedHud[]>('hud-presets', [])
  const next = [hud, ...current]
  writeStore('hud-presets', next)
  return next
}

export function upsertTraining(entry: TrainingEntry): TrainingEntry[] {
  const current = readStore<TrainingEntry[]>('training-history', [])
  const next = [entry, ...current.filter((item) => item.date !== entry.date)]
  writeStore('training-history', next)
  return next
}
