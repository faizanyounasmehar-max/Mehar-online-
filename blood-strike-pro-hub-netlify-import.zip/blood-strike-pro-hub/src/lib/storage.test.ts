import { beforeEach, describe, expect, it } from 'vitest'
import { makeDefaultSensitivity } from '../data/defaults'
import { addPreset, readStore } from './storage'
import { SCOPE_KEYS, SENSITIVITY_GROUPS, type SensitivityPreset } from '../types'

class MemoryStorage {
  private data = new Map<string, string>()
  getItem(key: string) { return this.data.get(key) ?? null }
  setItem(key: string, value: string) { this.data.set(key, value) }
  removeItem(key: string) { this.data.delete(key) }
  clear() { this.data.clear() }
}

beforeEach(() => {
  Object.defineProperty(globalThis, 'localStorage', { value: new MemoryStorage(), configurable: true })
})

describe('sensitivity workspace storage', () => {
  it('creates a complete 6-layer by 8-scope editable baseline', () => {
    const values = makeDefaultSensitivity()
    expect(SENSITIVITY_GROUPS).toHaveLength(6)
    expect(SCOPE_KEYS).toHaveLength(8)
    for (const group of SENSITIVITY_GROUPS) {
      for (const scope of SCOPE_KEYS) expect(values[group][scope]).toBe(100)
    }
  })

  it('persists no more than five saved presets', () => {
    const values = makeDefaultSensitivity()
    const create = (index: number): SensitivityPreset => ({
      id: String(index), name: `Preset ${index}`, createdAt: new Date().toISOString(),
      device: { model: '', screen: '', refreshRate: '60 Hz', ram: '', processor: '', android: '', touch: 'Unknown', gyro: 'Unknown', fingers: '3-finger', playstyle: 'Balanced' },
      values,
    })
    for (let i = 0; i < 5; i += 1) addPreset(create(i))
    expect(readStore<SensitivityPreset[]>('sensitivity-presets', [])).toHaveLength(5)
    expect(() => addPreset(create(6))).toThrow(/up to five/i)
  })
})
