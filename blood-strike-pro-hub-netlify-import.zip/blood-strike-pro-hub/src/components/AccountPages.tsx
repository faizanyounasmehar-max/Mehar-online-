import { useEffect, useState, type FormEvent } from 'react'
import { LockKeyhole, Shield, ShieldCheck } from 'lucide-react'
import { isSupabaseConfigured, supabase, type Profile } from '../lib/supabase'
import { PageHeading, Panel, PanelTitle, EmptyState } from './Layout'

export function ProfilePage({ profile, onProfileChange }: { profile: Profile | null; onProfileChange: () => Promise<void> }) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [favourites, setFavourites] = useState('')

  useEffect(() => {
    if (!supabase || !profile) return
    supabase.from('profiles').select('favourite_weapons').eq('id', profile.id).maybeSingle().then(({ data }) => setFavourites((data?.favourite_weapons ?? []).join(', ')))
  }, [profile])

  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setMessage('')
    if (!supabase) return
    if (password.length < 8) { setError('Use a password with at least 8 characters.'); return }
    setBusy(true)
    try {
      if (mode === 'signup') {
        const { data, error: authError } = await supabase.auth.signUp({ email, password, options: { data: { username: username.trim() } } })
        if (authError) throw authError
        if (!data.session) setMessage('Account created. Check your email to verify the address, then sign in.')
        else { setMessage('Account created successfully.'); await onProfileChange() }
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password })
        if (authError) throw authError
        setMessage('Signed in successfully.'); await onProfileChange()
      }
    } catch (err) { setError(err instanceof Error ? err.message : 'Authentication failed.') }
    finally { setBusy(false) }
  }

  const signOut = async () => { if (!supabase) return; const { error: signOutError } = await supabase.auth.signOut(); if (signOutError) setError(signOutError.message); else { setMessage('Signed out.'); await onProfileChange() } }
  const saveProfile = async () => {
    if (!supabase || !profile) return
    const next = favourites.split(',').map((item) => item.trim()).filter(Boolean).slice(0, 20)
    const { error: updateError } = await supabase.from('profiles').update({ favourite_weapons: next }).eq('id', profile.id)
    if (updateError) setError(updateError.message); else setMessage('Profile preferences saved.')
  }

  return <>
    <PageHeading eyebrow="PLAYER IDENTITY / 12" title="Player Profile" description="Manage your account, saved preferences and personal workspace identity." />
    {(message || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || message}</div>}
    {!isSupabaseConfigured ? <Panel><EmptyState icon={LockKeyhole} title="Account service not configured" description="Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your Netlify environment variables, run the included SQL schema, then redeploy to enable secure registration and login." /></Panel> : profile ? <div className="content-grid two-up"><Panel><div className="profile-hero"><div className="profile-avatar-large">{profile.username?.slice(0, 1).toUpperCase() || 'P'}</div><div><div className="eyebrow">AUTHENTICATED PLAYER</div><h2>{profile.username || 'Player'}</h2><span className={`role-pill ${profile.role === 'admin' ? 'admin' : ''}`}>{profile.role.toUpperCase()}</span></div></div><div className="profile-details"><div><small>PLAYER ID</small><b>{profile.id.slice(0, 8).toUpperCase()}…</b></div><div><small>ACCOUNT ROLE</small><b>{profile.role === 'admin' ? 'Administrator' : 'Player'}</b></div></div><button className="btn btn-secondary" onClick={signOut}>Sign out</button></Panel><Panel><PanelTitle title="Player preferences" subtitle="Favourite weapon names are personal notes, not verified catalog links." /><div className="field-stack"><label className="field-label">Favourite weapons (comma separated)</label><input className="text-input" value={favourites} onChange={(e) => setFavourites(e.target.value)} placeholder="Add your favourites" /></div><button className="btn btn-primary" onClick={saveProfile}>Save profile</button></Panel></div> : <Panel className="auth-panel"><div className="auth-illustration"><div className="auth-emblem"><Shield size={36} /></div><div className="eyebrow">PLAYER ACCESS</div><h2>{mode === 'signin' ? 'Welcome back.' : 'Create your player ID.'}</h2><p>Secure access for your saved configurations and community participation.</p></div><form className="auth-form" onSubmit={submit}><div className="segmented-tabs"><button type="button" className={mode === 'signin' ? 'selected' : ''} onClick={() => setMode('signin')}>Sign in</button><button type="button" className={mode === 'signup' ? 'selected' : ''} onClick={() => setMode('signup')}>Create account</button></div>{mode === 'signup' && <div className="field-stack"><label className="field-label">Gamer username</label><input className="text-input" value={username} maxLength={24} onChange={(e) => setUsername(e.target.value)} placeholder="Your player name" required /></div>}<div className="field-stack"><label className="field-label">Email address</label><input type="email" className="text-input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required /></div><div className="field-stack"><label className="field-label">Password</label><input type="password" className="text-input" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} placeholder="At least 8 characters" required /></div><button className="btn btn-primary full-width" type="submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'signin' ? 'Sign in securely' : 'Create player account'}</button><small className="field-help">Email verification and password policies follow your Supabase Auth settings.</small></form></Panel>}
  </>
}

export function AdminPage({ profile }: { profile: Profile | null }) {
  const [counts, setCounts] = useState<Record<string, number | null>>({})
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState('Update')
  const [body, setBody] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  useEffect(() => {
    if (!supabase || profile?.role !== 'admin') return
    const tables = ['profiles', 'weapons', 'operators', 'tournaments', 'community_posts', 'community_reports', 'support_messages']
    Promise.all(tables.map(async (table) => {
      const { count, error: queryError } = await supabase!.from(table).select('*', { count: 'exact', head: true })
      return [table, queryError ? null : count] as const
    })).then((rows) => setCounts(Object.fromEntries(rows)))
  }, [profile])

  const publishArticle = async () => {
    if (!supabase || profile?.role !== 'admin') return
    setMessage(''); setError('')
    if (!title.trim() || body.trim().length < 30) { setError('Enter a title and at least 30 characters of article content.'); return }
    const { error: insertError } = await supabase.from('articles').insert({ title: title.trim(), category, body: body.trim(), published: true, author_id: profile.id, published_at: new Date().toISOString() })
    if (insertError) setError(insertError.message); else { setMessage('Article published.'); setTitle(''); setBody('') }
  }

  return <>
    <PageHeading eyebrow="PLATFORM CONTROL / RESTRICTED" title="Admin Console" description="Administrative actions are protected by Supabase Row Level Security. UI visibility alone is not an authorization boundary." />
    {profile?.role !== 'admin' ? <Panel><EmptyState icon={LockKeyhole} title="Administrator access required" description="Sign in with an account promoted to admin through the trusted database setup process. Do not change roles from the browser." /></Panel> : <>
      <div className="notice notice-success"><ShieldCheck size={16} /><span>Admin identity verified from the Supabase profile record. Database policies remain the final enforcement layer.</span></div>
      <div className="metric-grid three-metrics">{Object.entries(counts).map(([table, count]) => <div className="admin-count" key={table}><small>{table.replaceAll('_', ' ')}</small><b>{count == null ? '—' : count}</b></div>)}</div>
      <div className="content-grid two-up"><Panel><PanelTitle title="Publish an article" subtitle="Publish an update to the hub news feed." /><div className="field-stack"><label className="field-label">Article title</label><input className="text-input" value={title} maxLength={120} onChange={(e) => setTitle(e.target.value)} /></div><div className="field-stack"><label className="field-label">Category</label><select className="text-input" value={category} onChange={(e) => setCategory(e.target.value)}>{['Update', 'Guide', 'Tournament', 'Community', 'Patch notes'].map((item) => <option key={item}>{item}</option>)}</select></div><div className="field-stack"><label className="field-label">Article content</label><textarea className="text-input text-area" value={body} maxLength={10000} onChange={(e) => setBody(e.target.value)} /></div><button className="btn btn-primary" onClick={publishArticle}>Publish article</button>{(message || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || message}</div>}</Panel><Panel><PanelTitle title="Admin operations" subtitle="Use the database console for additional protected table management." /><div className="admin-action-list">{['Verify weapon and operator source records', 'Manage tournament schedule and registrations', 'Review community reports and moderation status', 'Publish media links with creator attribution', 'Review player accounts and role assignments'].map((item, index) => <div key={item}><span>0{index + 1}</span><b>{item}</b></div>)}</div><p className="subtle-note">This starter includes the schema, RLS rules and article publishing flow. Full media storage, bulk account management and bracket operations require your project-specific admin workflow.</p></Panel></div>
    </>}
  </>
}

export function AboutPage() {
  return <>
    <PageHeading eyebrow="PLATFORM INFORMATION / 13" title="About & Policies" description="Transparency, privacy, terms and safe use information for this independent companion platform." />
    <div className="content-grid two-up">
      <Panel><PanelTitle title="About Blood Strike Pro Hub" /><p className="body-copy">Blood Strike Pro Hub is an independent community companion dedicated to NETEASE Blood Strike Mobile. It provides personal configuration tools, training checklists and database-driven community resources. It is not an official game service and is not affiliated with or endorsed by NetEase.</p><p className="body-copy">Game names and marks belong to their respective owners. All weapon, operator, tournament and media records should be sourced and reviewed before publication. Users are responsible for following the game's rules and third-party platform terms.</p></Panel>
      <Panel><PanelTitle title="Privacy policy" /><p className="body-copy"><b>Local storage:</b> sensitivity values, presets, loadouts, HUD drafts, device checklist and training progress are stored in this browser's local storage. Clearing browser data removes them. Export files before changing devices.</p><p className="body-copy"><b>Account data:</b> when Supabase is configured, email authentication, usernames, profile preferences, community posts, support tickets and registration records are stored in the site owner's Supabase project. Access is governed by the included Row Level Security policies.</p><p className="body-copy"><b>AI assistant:</b> prompts are sent from a Netlify server function to the AI provider configured by the site owner. API keys are not intentionally exposed to the browser. Avoid submitting secrets or sensitive personal information.</p><p className="body-copy"><b>Retention and requests:</b> the site owner must configure project retention, backups and a privacy contact before public launch. Users can request account/data handling from the site owner through the support page.</p></Panel>
      <Panel><PanelTitle title="Terms of service" /><p className="body-copy">Use this site as an informational and organizational companion. No game client modification, cheating, automation, exploit or unauthorized access is provided or endorsed. Do not upload content you do not own or have permission to share.</p><p className="body-copy">Configurations are user-generated starting points and require in-game testing. No guaranteed zero recoil, FPS, ping, win rate, tournament placement or competitive outcome is promised. Game features, weapon balance, operators and scope availability can change; verify information against the current game build.</p><p className="body-copy">Community content may be removed if it violates rules or is reported. Tournament details are controlled by the event organizer, not by this tool.</p></Panel>
      <Panel><PanelTitle title="Security, cookies & analytics" /><p className="body-copy">The starter does not include third-party advertising or a bundled analytics tracker. Supabase authentication may use browser storage to maintain sessions. Netlify may process standard deployment and function logs.</p><p className="body-copy">The site owner should add a production privacy notice that identifies the deployed domain, legal operator, jurisdiction, support contact, analytics/cookie choices and applicable data rights before launch.</p><p className="body-copy">Report suspected security issues privately through the support page. Never post credentials, access tokens or exploit details in the public community feed.</p></Panel>
    </div>
  </>
}

export function ContactPage({ onSignIn }: { onSignIn: () => void }) {
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setStatus('')
    if (!supabase) { setError('Connect Supabase before sending a support request.'); return }
    if (subject.trim().length < 4 || message.trim().length < 20) { setError('Add a subject and at least 20 characters of detail.'); return }
    setBusy(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { onSignIn(); return }
      const { error: insertError } = await supabase.from('support_messages').insert({ subject: subject.trim(), message: message.trim() })
      if (insertError) throw insertError
      setStatus('Support request submitted. You can track it through your platform administrator.')
      setSubject(''); setMessage('')
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not submit your support request.') }
    finally { setBusy(false) }
  }
  return <>
    <PageHeading eyebrow="HELP DESK / CONTACT" title="Contact Support" description="Send a support request to the site owner. This form stores a private ticket in your connected Supabase project." />
    {(status || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || status}</div>}
    <div className="content-grid two-up"><Panel><PanelTitle title="Send a support request" subtitle="Do not include passwords, API keys or other account secrets." />{!isSupabaseConfigured ? <EmptyState icon={LockKeyhole} title="Support inbox not configured" description="Connect Supabase and apply the schema to enable authenticated support requests." /> : <form onSubmit={submit}><div className="field-stack"><label className="field-label">Subject</label><input className="text-input" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={120} required placeholder="What do you need help with?" /></div><div className="field-stack"><label className="field-label">Message</label><textarea className="text-input text-area" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={3000} required placeholder="Describe the issue and the steps to reproduce it…" /></div><button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Submitting…' : 'Submit support request'}</button></form>}</Panel><Panel><PanelTitle title="Before you contact us" /><div className="admin-action-list"><div><span>01</span><b>Include the device model and Android version when reporting a technical issue.</b></div><div><span>02</span><b>Tell us which page or feature you were using and what you expected to happen.</b></div><div><span>03</span><b>Remove account identifiers, passwords, tokens and private information from screenshots.</b></div></div></Panel></div>
  </>
}
