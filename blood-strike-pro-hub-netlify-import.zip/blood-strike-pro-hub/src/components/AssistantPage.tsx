import { useState } from 'react'
import { Bot, MessageCircle, Send, ShieldCheck, Sparkles, UserRound } from 'lucide-react'
import { PageHeading, Panel, PanelTitle } from './Layout'
import { isSupabaseConfigured, supabase } from '../lib/supabase'

type ChatMessage = { role: 'user' | 'assistant'; content: string }

const suggested = [
  'Help me tune sensitivity for a 3-finger Android setup.',
  'Build a 20-minute recoil-control practice routine.',
  'Explain how to compare two sensitivity presets.',
  'What should I check when FPS feels unstable?',
]

export default function AssistantPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', content: 'I can help with Blood Strike Mobile sensitivity concepts, device-safe troubleshooting, loadout planning and practice routines. Share your device and control setup for more useful guidance. I will flag details that need in-game verification.' }])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')

  const send = async (text = input) => {
    const clean = text.trim()
    if (!clean || sending) return
    if (clean.length > 2000) { setError('Keep each message under 2,000 characters.'); return }
    setError('')
    if (!isSupabaseConfigured || !supabase) { setError('Connect Supabase and sign in to use the AI assistant.'); return }
    setSending(true)
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      if (sessionError) throw sessionError
      if (!session?.access_token) { setError('Sign in to your player account before using the AI assistant.'); return }
      const next = [...messages, { role: 'user' as const, content: clean }]
      setMessages(next); setInput('')
      const response = await fetch('/api/assistant', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ messages: next.slice(-12) }),
      })
      const result = await response.json() as { answer?: string; error?: string }
      if (!response.ok) throw new Error(result.error || `Assistant request failed (${response.status}).`)
      if (!result.answer) throw new Error('The assistant returned an empty answer.')
      setMessages((current) => [...current, { role: 'assistant', content: result.answer! }])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not reach the assistant. Configure the server function and try again.')
    } finally { setSending(false) }
  }

  return <>
    <PageHeading eyebrow="INTELLIGENCE SUPPORT / 10" title="AI Blood Strike Assistant" description="A sign-in protected helper for setup questions, aiming fundamentals and safe troubleshooting. API credentials stay on the server." />
    <div className="assistant-layout">
      <Panel className="assistant-chat-panel">
        <div className="assistant-chat-head"><div className="assistant-badge"><Bot size={22} /></div><div><b>PRO HUB / FIELD ASSISTANT</b><small><span className="live-dot" /> Signed-in access · Secure server route · OpenAI API</small></div><span className="micro-tag">BETA</span></div>
        <div className="chat-transcript" aria-live="polite">{messages.map((message, index) => <div className={`chat-message ${message.role}`} key={`${message.role}-${index}`}><div className="chat-avatar">{message.role === 'assistant' ? <Bot size={16} /> : <UserRound size={16} />}</div><div className="chat-bubble"><small>{message.role === 'assistant' ? 'PRO HUB ASSISTANT' : 'YOU'}</small><p>{message.content}</p></div></div>)}{sending && <div className="chat-message assistant"><div className="chat-avatar"><Bot size={16} /></div><div className="chat-bubble typing"><span /><span /><span /></div></div>}</div>
        {error && <div className="notice notice-error">{error}</div>}
        <form className="chat-compose" onSubmit={(e) => { e.preventDefault(); void send() }}><input value={input} onChange={(e) => setInput(e.target.value)} maxLength={2000} placeholder="Ask about sensitivity, recoil, practice…" disabled={sending} /><button className="btn btn-primary" disabled={sending || !input.trim()} type="submit"><Send size={16} /><span>Send</span></button></form>
      </Panel>
      <div className="assistant-side"><Panel><PanelTitle title="Suggested prompts" subtitle="Choose a starting point." />{suggested.map((prompt) => <button className="suggested-prompt" key={prompt} onClick={() => void send(prompt)} disabled={sending}><Sparkles size={15} /><span>{prompt}</span></button>)}</Panel><Panel><PanelTitle title="Use responsibly" /><div className="assistant-disclaimer"><ShieldCheck size={18} /><p>Assistant output is guidance, not verified game telemetry. Test sensitivity changes in-game, confirm current weapon/operator details from official or sourced references, and never share passwords or account secrets.</p></div><div className="assistant-disclaimer"><MessageCircle size={18} /><p>For best results, include phone model, refresh rate, finger layout, gyro status and the issue you are trying to fix.</p></div></Panel></div>
    </div>
  </>
}
