import { useEffect, useState } from 'react'
import { Activity, ArrowUpRight, BatteryCharging, Check, ChevronRight, Cpu, Database, ExternalLink, Gauge, Globe2, HardDrive, Heart, MessageSquare, Play, Send, ShieldCheck, Smartphone, Target, Trophy, Wifi, Zap } from 'lucide-react'
import { isSupabaseConfigured, supabase } from '../lib/supabase'
import { readStore, writeStore } from '../lib/storage'
import { MetricCard, PageHeading, Panel, PanelTitle, EmptyState } from './Layout'
import { TRAINING_MODULES } from '../data/defaults'

export function OverviewPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [presetCount] = useState(() => readStore<unknown[]>('sensitivity-presets', []).length)
  const [loadoutCount] = useState(() => readStore<unknown[]>('loadouts', []).length)
  const [hudCount] = useState(() => readStore<unknown[]>('hud-presets', []).length)
  const [trainingCount] = useState(() => readStore<{ completed: string[]; date: string }[]>('training-history', []).slice(0, 1)[0]?.completed.length ?? 0)
  const [content, setContent] = useState<{ title: string; category: string; published_at: string }[]>([])
  useEffect(() => {
    if (!supabase) return
    supabase.from('articles').select('title,category,published_at').eq('published', true).order('published_at', { ascending: false }).limit(3).then(({ data }) => setContent(data ?? []))
  }, [])
  const quick = [
    { id: 'sensitivity', tag: '01 / AIM CONTROL', title: 'Sensitivity Lab', description: 'Tune camera, ADS, firing and gyro values.', icon: Gauge },
    { id: 'loadouts', tag: '02 / ARMORY', title: 'Loadout Builder', description: 'Create and compare your personal setups.', icon: ShieldCheck },
    { id: 'hud', tag: '03 / CONTROLS', title: 'HUD Studio', description: 'Plan your 2–5 finger control layout.', icon: Smartphone },
    { id: 'training', tag: '04 / DEVELOPMENT', title: 'Aim Training', description: 'Build a consistent practice routine.', icon: Target },
  ]
  return <>
    <section className="hero-panel">
      <div className="hero-content"><div className="eyebrow"><span /> TACTICAL COMPANION PLATFORM</div><h1>OWN YOUR<br /><em>ADVANTAGE.</em></h1><p>Fine-tune your controls. Build smarter loadouts. Train with intent. Your independent Blood Strike Mobile command center.</p><div className="hero-actions"><button className="btn btn-primary" onClick={() => onNavigate('sensitivity')}>Open Sensitivity Lab <ArrowUpRight size={16} /></button><button className="btn btn-hero-ghost" onClick={() => onNavigate('training')}>Start training <ChevronRight size={16} /></button></div><div className="hero-meta"><span><i className="live-dot" /> PERSONAL WORKSPACE READY</span><span>COMMUNITY COMPANION · NOT OFFICIAL</span></div></div>
      <div className="hero-art"><div className="hero-ring ring-one" /><div className="hero-ring ring-two" /><div className="hero-cross"><span /><i /></div><div className="hero-vertical">BS / PRO HUB</div><div className="hero-coordinate">FIELD NOTES<br />MOBILE DIVISION<br />01—08</div></div>
      <div className="hero-index">BS<span> / </span>001</div>
    </section>
    <div className="metric-grid four-metrics"><MetricCard label="Sensitivity presets" value={String(presetCount)} detail="Saved on this device" icon={Gauge} /><MetricCard label="Loadout builds" value={String(loadoutCount)} detail="Personal configurations" icon={ShieldCheck} accent="purple" /><MetricCard label="HUD layouts" value={String(hudCount)} detail="Custom previews saved" icon={Smartphone} /><MetricCard label="Today's drills" value={`${trainingCount}/${TRAINING_MODULES.length}`} detail="Checklist progress" icon={Activity} accent="green" /></div>
    <div className="section-row-heading"><div><div className="eyebrow">YOUR TOOLKIT</div><h2>Mission control</h2></div><span className="muted-inline">Choose a module to continue</span></div>
    <div className="quick-grid">{quick.map((item, i) => <button className="quick-card" key={item.id} onClick={() => onNavigate(item.id)}><div className="quick-card-top"><span>{item.tag}</span><item.icon size={20} /></div><h3>{item.title}</h3><p>{item.description}</p><div className="quick-card-bottom"><span>OPEN MODULE</span><ArrowUpRight size={16} /></div><div className="quick-number">0{i + 1}</div></button>)}</div>
    <div className="content-grid two-up dashboard-bottom">
      <Panel><PanelTitle title="Latest hub updates" subtitle="Published articles from your connected database." right={<button className="text-action" onClick={() => onNavigate('media')}>Media center <ArrowUpRight size={13} /></button>} />{content.length ? <div className="article-list">{content.map((item, index) => <div className="article-row" key={`${item.title}-${index}`}><span className="article-number">0{index + 1}</span><div><b>{item.title}</b><small>{item.category || 'Update'} · {item.published_at ? new Date(item.published_at).toLocaleDateString() : 'Date not listed'}</small></div><ChevronRight size={16} /></div>)}</div> : <EmptyState icon={Database} title="No published updates" description="Articles will appear here after an editor publishes verified content." />}</Panel>
      <Panel><PanelTitle title="Community & competition" subtitle="Player-created information, not live game telemetry." /><div className="feature-row" onClick={() => onNavigate('tournaments')} role="button" tabIndex={0}><div className="feature-icon purple"><Trophy size={19} /></div><div><b>Tournament center</b><small>Check event records and registration windows.</small></div><ArrowUpRight size={16} /></div><div className="feature-row" onClick={() => onNavigate('community')} role="button" tabIndex={0}><div className="feature-icon red"><Globe2 size={19} /></div><div><b>Community hub</b><small>Discuss setups and share field notes.</small></div><ArrowUpRight size={16} /></div><div className="feature-row" onClick={() => onNavigate('assistant')} role="button" tabIndex={0}><div className="feature-icon blue"><Zap size={19} /></div><div><b>AI tactical assistant</b><small>Ask for help with tuning and practice.</small></div><ArrowUpRight size={16} /></div></Panel>
    </div>
  </>
}

export function DeviceCenter() {
  const tasks = [
    { id: 'graphics', title: 'Choose a stable graphics preset', detail: 'Start with a setting your phone can sustain without frame pacing drops.' },
    { id: 'fps', title: 'Match FPS to stable device output', detail: 'A consistent frame rate can feel better than a higher but unstable target.' },
    { id: 'storage', title: 'Keep sufficient free storage', detail: 'Remove downloads and unused apps through Android Settings; avoid deleting unknown system files.' },
    { id: 'battery', title: 'Check battery and power mode', detail: 'Disable battery saver during play only when appropriate for your device and temperature.' },
    { id: 'thermal', title: 'Watch device temperature', detail: 'Take breaks, remove heat-trapping cases if safe, and avoid charging in hot conditions.' },
    { id: 'network', title: 'Test a stable network path', detail: 'Use a reliable Wi-Fi signal or mobile data connection; avoid untrusted VPN and booster apps.' },
    { id: 'background', title: 'Close unnecessary background apps', detail: 'Close apps you recognize and do not need; do not use aggressive task-killer tools.' },
    { id: 'updates', title: 'Keep game and system software updated', detail: 'Install updates from official stores and your device manufacturer.' },
  ]
  const [checked, setChecked] = useState<string[]>(() => readStore('device-checklist', []))
  const toggle = (id: string) => { const next = checked.includes(id) ? checked.filter((x) => x !== id) : [...checked, id]; setChecked(next); writeStore('device-checklist', next) }
  const [expanded, setExpanded] = useState('network')
  return <>
    <PageHeading eyebrow="ANDROID PERFORMANCE / 06" title="Device Optimization Center" description="Practical, reversible checks for stability, responsiveness and network reliability. No root, debloat scripts or unsafe system modifications." />
    <div className="metric-grid three-metrics"><MetricCard label="Checklist progress" value={`${checked.length}/${tasks.length}`} detail="Saved on this device" icon={Check} /><MetricCard label="Device profile" value={readStore<{ model: string }>('device-profile', { model: '' }).model || 'Not set'} detail="Sensitivity Lab profile" icon={Smartphone} accent="purple" /><MetricCard label="Optimization mode" value="Safe" detail="No system modifications" icon={ShieldCheck} accent="green" /></div>
    <div className="content-grid two-up">
      <Panel><PanelTitle title="Performance checklist" subtitle="Check each step after reviewing your device settings." /><div className="checklist-list">{tasks.map((task, index) => <label className={`device-check ${checked.includes(task.id) ? 'checked' : ''}`} key={task.id}><input type="checkbox" checked={checked.includes(task.id)} onChange={() => toggle(task.id)} /><span className="check-count">{String(index + 1).padStart(2, '0')}</span><span><b>{task.title}</b><small>{task.detail}</small></span></label>)}</div><button className="btn btn-ghost btn-small" onClick={() => { setChecked([]); writeStore('device-checklist', []) }}>Reset checklist</button></Panel>
      <Panel><PanelTitle title="Quick reference" subtitle="Safe, general troubleshooting topics." />
        <Guide icon={Wifi} title="Wi-Fi & latency" open={expanded === 'network'} onClick={() => setExpanded(expanded === 'network' ? '' : 'network')}>Move closer to your router, test another trusted network, pause large downloads, and restart your router if needed. Do not share your Wi-Fi password or install unknown ping-reducer apps.</Guide>
        <Guide icon={BatteryCharging} title="Battery & thermals" open={expanded === 'battery'} onClick={() => setExpanded(expanded === 'battery' ? '' : 'battery')}>High temperatures can lead to performance throttling. Play in a ventilated environment, avoid direct sunlight and stop if the device becomes unusually hot.</Guide>
        <Guide icon={Cpu} title="Graphics & FPS" open={expanded === 'fps'} onClick={() => setExpanded(expanded === 'fps' ? '' : 'fps')}>Test one graphics setting at a time. Prefer stable frame pacing over a target the device cannot maintain. Available options vary by phone and game version.</Guide>
        <Guide icon={HardDrive} title="Storage & updates" open={expanded === 'storage'} onClick={() => setExpanded(expanded === 'storage' ? '' : 'storage')}>Use Android's built-in storage manager and official app store updates. Avoid deleting folders or changing system permissions without understanding their purpose.</Guide>
        <div className="notice notice-warning"><ShieldCheck size={16} /><span>We do not promise a specific FPS, ping or battery improvement. Results depend on the phone, OS, network, ambient temperature and game build.</span></div>
      </Panel>
    </div>
  </>
}

export function TournamentsPage({ onSignIn }: { onSignIn: () => void }) {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(isSupabaseConfigured)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  useEffect(() => { let live = true; if (!supabase) return; supabase.from('tournaments').select('*').order('starts_at', { ascending: true }).then(({ data, error: queryError }) => { if (!live) return; setItems(data ?? []); if (queryError) setError(queryError.message); setLoading(false) }); return () => { live = false } }, [])
  const register = async (id: string) => {
    if (!supabase) return
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { onSignIn(); return }
    const { error: insertError } = await supabase.from('tournament_registrations').insert({ tournament_id: id, user_id: user.id })
    if (insertError) setError(insertError.message); else setMessage('Registration request submitted.')
  }
  return <>
    <PageHeading eyebrow="COMPETITIVE OPERATIONS / 08" title="Esports & Tournaments" description="Browse database-published events, match records and registration windows. No live scores or rankings are fabricated." />
    {(message || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || message}</div>}
    <Panel><PanelTitle title="Tournament schedule" subtitle="Events published by authorized organizers." right={<span className="micro-tag">DATABASE FEED</span>} />{loading ? <div className="loading-line">Loading tournament records…</div> : items.length ? <div className="event-list">{items.map((item) => <article className="event-row" key={item.id}><div className="event-date"><b>{item.starts_at ? new Date(item.starts_at).toLocaleDateString(undefined, { day: '2-digit' }) : '—'}</b><small>{item.starts_at ? new Date(item.starts_at).toLocaleDateString(undefined, { month: 'short', year: 'numeric' }) : 'TBD'}</small></div><div className="event-main"><div className="event-tags"><span>{item.status || 'Status not published'}</span>{item.region && <span>{item.region}</span>}</div><h3>{item.name}</h3><p>{item.description || 'Details have not been published.'}</p><small>{item.format || 'Format TBD'} · {item.team_size ? `${item.team_size} players` : 'Team size TBD'}</small></div><button className="btn btn-secondary btn-small" disabled={item.status !== 'registration_open'} onClick={() => register(item.id)}>Register</button></article>)}</div> : <EmptyState icon={Trophy} title={isSupabaseConfigured ? 'No tournaments published' : 'Tournament feed not connected'} description={isSupabaseConfigured ? 'No event records are currently published. Organizers can add events through the admin workflow.' : 'Connect Supabase and publish actual tournament records. Registration is disabled until a real event and authenticated user exist.'} />}</Panel>
    <div className="notice notice-info"><Database size={16} /><span>Bracket generation, registration limits, match results and ranking updates should be maintained by event administrators. This starter only displays stored event records and accepts a registration row when enabled.</span></div>
  </>
}

export function MediaPage() {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(isSupabaseConfigured)
  const [category, setCategory] = useState('All')
  const [error, setError] = useState('')
  useEffect(() => { let live = true; if (!supabase) return; supabase.from('media_items').select('*').eq('verified', true).order('created_at', { ascending: false }).then(({ data, error: queryError }) => { if (!live) return; setItems(data ?? []); if (queryError) setError(queryError.message); setLoading(false) }); return () => { live = false } }, [])
  const filtered = items.filter((item) => category === 'All' || item.category === category)
  return <>
    <PageHeading eyebrow="CREATOR NETWORK / 09" title="Gaming Media Center" description="A curated index of Blood Strike Mobile tutorials, clips and creator coverage. Links are displayed only from published database records." />
    <Panel><div className="filter-row">{['All', 'Tutorial', 'Gameplay', 'Shorts', 'Review', 'News'].map((item) => <button className={`filter-chip ${category === item ? 'active' : ''}`} key={item} onClick={() => setCategory(item)}>{item}</button>)}</div>{loading ? <div className="loading-line">Loading media library…</div> : error ? <div className="notice notice-error">Could not load media: {error}</div> : filtered.length ? <div className="media-grid">{filtered.map((item) => <article className="media-card" key={item.id}><a href={item.url} target="_blank" rel="noreferrer" className="media-thumb">{item.thumbnail_url ? <img src={item.thumbnail_url} alt="" loading="lazy" /> : <div className="media-placeholder"><Play size={25} /></div>}<span><Play size={14} fill="currentColor" /></span></a><div className="media-card-copy"><div className="event-tags"><span>{item.category}</span>{item.platform && <span>{item.platform}</span>}</div><h3>{item.title}</h3><small>{item.creator || 'Creator not listed'}</small><a href={item.url} target="_blank" rel="noreferrer" className="text-action">Open original <ExternalLink size={13} /></a></div></article>)}</div> : <EmptyState icon={Play} title="No media entries published" description="Add legitimate creator links, source attribution and optional thumbnails in the media_items table. Embedded playback is not proxied or rehosted by this site." />}</Panel>
  </>
}

export function CommunityPage({ onSignIn }: { onSignIn: () => void }) {
  const [posts, setPosts] = useState<any[]>([])
  const [body, setBody] = useState('')
  const [loading, setLoading] = useState(isSupabaseConfigured)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [likedIds, setLikedIds] = useState<string[]>([])
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({})
  const [openComments, setOpenComments] = useState<string | null>(null)
  const [comments, setComments] = useState<Record<string, any[]>>({})
  const [commentDrafts, setCommentDrafts] = useState<Record<string, string>>({})

  const refresh = async () => {
    if (!supabase) return
    const { data, error: queryError } = await supabase.from('community_posts').select('id,body,created_at,profiles(username)').eq('status', 'published').order('created_at', { ascending: false }).limit(50)
    if (queryError) { setError(queryError.message); setLoading(false); return }
    const currentPosts = data ?? []
    setPosts(currentPosts)
    if (currentPosts.length) {
      const ids = currentPosts.map((post: any) => post.id)
      const [{ data: likeRows }, { data: authData }] = await Promise.all([
        supabase.from('community_likes').select('post_id,user_id').in('post_id', ids),
        supabase.auth.getUser(),
      ])
      const rows = likeRows ?? []
      const counts: Record<string, number> = {}
      rows.forEach((row: any) => { counts[row.post_id] = (counts[row.post_id] ?? 0) + 1 })
      setLikeCounts(counts)
      setLikedIds(rows.filter((row: any) => row.user_id === authData.user?.id).map((row: any) => row.post_id))
    }
    setLoading(false)
  }
  useEffect(() => { void refresh() }, [])

  const submit = async () => {
    if (!supabase) return
    setError(''); setMessage('')
    if (body.trim().length < 8) { setError('Write at least 8 characters before posting.'); return }
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { onSignIn(); return }
    const { error: insertError } = await supabase.from('community_posts').insert({ body: body.trim() })
    if (insertError) setError(insertError.message); else { setBody(''); setMessage('Your post was published to the community feed.'); await refresh() }
  }

  const toggleLike = async (postId: string) => {
    if (!supabase) return
    setError('')
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { onSignIn(); return }
    if (likedIds.includes(postId)) {
      const { error: deleteError } = await supabase.from('community_likes').delete().eq('post_id', postId).eq('user_id', user.id)
      if (deleteError) setError(deleteError.message)
    } else {
      const { error: likeError } = await supabase.from('community_likes').insert({ post_id: postId, user_id: user.id })
      if (likeError) setError(likeError.message)
    }
    await refresh()
  }

  const loadComments = async (postId: string) => {
    if (!supabase) return
    if (openComments === postId) { setOpenComments(null); return }
    setOpenComments(postId)
    const { data, error: queryError } = await supabase.from('community_comments').select('id,body,created_at,profiles(username)').eq('post_id', postId).eq('status', 'published').order('created_at', { ascending: true })
    if (queryError) setError(queryError.message); else setComments((current) => ({ ...current, [postId]: data ?? [] }))
  }

  const submitComment = async (postId: string) => {
    if (!supabase) return
    const text = (commentDrafts[postId] ?? '').trim()
    if (!text) { setError('Write a comment before submitting.'); return }
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { onSignIn(); return }
    const { error: insertError } = await supabase.from('community_comments').insert({ post_id: postId, body: text })
    if (insertError) setError(insertError.message); else {
      setCommentDrafts((current) => ({ ...current, [postId]: '' }))
      const { data } = await supabase.from('community_comments').select('id,body,created_at,profiles(username)').eq('post_id', postId).eq('status', 'published').order('created_at', { ascending: true })
      setComments((current) => ({ ...current, [postId]: data ?? [] }))
    }
  }

  const report = async (postId: string) => {
    if (!supabase) return
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { onSignIn(); return }
    const { error: reportError } = await supabase.from('community_reports').insert({ post_id: postId, reporter_id: user.id, reason: 'Community review requested' })
    if (reportError) setError(reportError.message); else setMessage('Report submitted for moderator review.')
  }

  return <>
    <PageHeading eyebrow="PLAYER NETWORK / 11" title="Community Center" description="A moderated player discussion space. Sign in to publish, react, comment and report content; posts are database-backed." />
    {(message || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || message}</div>}
    <Panel><PanelTitle title="Start a discussion" subtitle="Share an observation, setup note or question. Avoid personal information." /><textarea className="text-input community-composer" value={body} onChange={(e) => setBody(e.target.value)} maxLength={1000} placeholder="Share a Blood Strike tip or ask the community…" /><div className="composer-bottom"><span>{body.length}/1000</span><button className="btn btn-primary btn-small" onClick={submit}><Send size={13} /> Publish post</button></div></Panel>
    <Panel><PanelTitle title="Player discussions" subtitle="Newest 50 published posts." />{!isSupabaseConfigured ? <EmptyState icon={Database} title="Community backend not connected" description="Connect Supabase and apply the SQL schema to enable authenticated posts, likes, comments and moderation." /> : loading ? <div className="loading-line">Loading community posts…</div> : posts.length ? <div className="post-list">{posts.map((post) => <article className="community-post" key={post.id}><div className="post-avatar">{String(post.profiles?.username ?? 'P').slice(0, 1).toUpperCase()}</div><div className="post-copy"><div className="post-head"><b>{post.profiles?.username ?? 'Player'}</b><small>{new Date(post.created_at).toLocaleString()}</small></div><p>{post.body}</p><div className="post-actions"><button className={`text-action ${likedIds.includes(post.id) ? 'liked' : ''}`} onClick={() => toggleLike(post.id)}><Heart size={14} fill={likedIds.includes(post.id) ? 'currentColor' : 'none'} /> {likeCounts[post.id] ?? 0} likes</button><button className="text-action" onClick={() => void loadComments(post.id)}><MessageSquare size={14} /> Comments</button><button className="text-action" onClick={() => report(post.id)}>Report</button></div>
      {openComments === post.id && <div className="comment-thread">{(comments[post.id] ?? []).map((comment) => <div className="comment-row" key={comment.id}><b>{comment.profiles?.username ?? 'Player'}</b><p>{comment.body}</p><small>{new Date(comment.created_at).toLocaleString()}</small></div>)}{(comments[post.id] ?? []).length === 0 && <small className="comment-empty">No comments yet. Start a constructive discussion.</small>}<div className="comment-compose"><input className="text-input" value={commentDrafts[post.id] ?? ''} onChange={(e) => setCommentDrafts((current) => ({ ...current, [post.id]: e.target.value }))} maxLength={1000} placeholder="Write a comment…" /><button className="btn btn-secondary btn-small" onClick={() => void submitComment(post.id)}>Reply</button></div></div>}
    </div></article>)}</div> : <EmptyState icon={Activity} title="No community posts yet" description="Be the first to start a useful discussion once your account is connected." />}</Panel>
  </>
}

function Guide({ icon: Icon, title, open, onClick, children }: { icon: typeof Wifi; title: string; open: boolean; onClick: () => void; children: string }) {
  return <div className={`guide-item ${open ? 'open' : ''}`}><button onClick={onClick}><Icon size={17} /><b>{title}</b><span>{open ? '−' : '+'}</span></button>{open && <p>{children}</p>}</div>
}

export function NotFoundPage({ onHome }: { onHome: () => void }) {
  return <div className="not-found"><div className="eyebrow"><span /> ERROR / 404</div><div className="not-found-code">404</div><h1>FIELD NOT FOUND</h1><p>This route is not part of the Blood Strike Pro Hub command menu.</p><button className="btn btn-primary" onClick={onHome}>Return to command center <ArrowUpRight size={15} /></button></div>
}
