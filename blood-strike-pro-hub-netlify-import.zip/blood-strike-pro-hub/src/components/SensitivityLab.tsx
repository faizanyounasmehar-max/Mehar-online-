import { useMemo, useState } from 'react'
import { Activity, Copy, Download, History, RotateCcw, Save, SlidersHorizontal, Trash2 } from 'lucide-react'
import { DEFAULT_DEVICE, makeDefaultSensitivity } from '../data/defaults'
import { addPreset, readStore, writeStore } from '../lib/storage'
import { copyText, downloadJson, makeId } from '../lib/utils'
import { SCOPE_KEYS, SENSITIVITY_GROUPS, type DeviceProfile, type SensitivityGroup, type SensitivityPreset, type ScopeKey, type SensitivityValues } from '../types'
import { EmptyState, PageHeading, Panel, PanelTitle } from './Layout'

const groupNotes: Record<SensitivityGroup, string> = {
  Camera: 'View movement before firing. Tune for comfortable target acquisition.',
  ADS: 'Aim-down-sight camera movement while scoped. Tune for controlled tracking.',
  Firing: 'Touch input while firing. Change in small steps to manage recoil correction.',
  'Gyro Camera': 'Gyroscope camera movement when not firing. Keep wrist movement comfortable.',
  'Gyro ADS': 'Gyroscope movement while aiming down sights.',
  'Gyro Firing': 'Gyroscope movement during fire. Test recoil correction in the range.',
}

function initialValues() {
  return readStore<SensitivityValues>('sensitivity-values', makeDefaultSensitivity())
}
function initialDevice() {
  return readStore<DeviceProfile>('device-profile', DEFAULT_DEVICE)
}

export default function SensitivityLab() {
  const [values, setValues] = useState<SensitivityValues>(initialValues)
  const [device, setDevice] = useState<DeviceProfile>(initialDevice)
  const [group, setGroup] = useState<SensitivityGroup>('Camera')
  const [presetName, setPresetName] = useState('My tuned setup')
  const [presets, setPresets] = useState<SensitivityPreset[]>(() => readStore('sensitivity-presets', []))
  const [history, setHistory] = useState<{ id: string; label: string; date: string; changed: number }[]>(() => readStore('sensitivity-history', []))
  const [compareA, setCompareA] = useState('')
  const [compareB, setCompareB] = useState('')
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')

  const updateValue = (scope: ScopeKey, nextValue: number) => {
    const next = { ...values, [group]: { ...values[group], [scope]: nextValue } }
    setValues(next)
    writeStore('sensitivity-values', next)
    setNotice('')
  }
  const updateDevice = <K extends keyof DeviceProfile>(key: K, value: DeviceProfile[K]) => {
    const next = { ...device, [key]: value }
    setDevice(next)
    writeStore('device-profile', next)
  }
  const savePreset = () => {
    setError(''); setNotice('')
    if (!presetName.trim()) { setError('Enter a name for this preset.'); return }
    try {
      const next = addPreset({ id: makeId(), name: presetName.trim(), createdAt: new Date().toISOString(), device, values })
      setPresets(next)
      setNotice(`“${presetName.trim()}” saved on this device.`)
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not save preset.') }
  }
  const loadPreset = (preset: SensitivityPreset) => {
    setValues(preset.values); setDevice(preset.device)
    writeStore('sensitivity-values', preset.values); writeStore('device-profile', preset.device)
    setNotice(`Loaded ${preset.name}.`); setError('')
  }
  const deletePreset = (id: string) => {
    const next = presets.filter((preset) => preset.id !== id)
    setPresets(next); writeStore('sensitivity-presets', next)
    setNotice('Preset deleted.')
  }
  const reset = () => {
    const next = makeDefaultSensitivity()
    setValues(next); writeStore('sensitivity-values', next)
    setNotice('Values reset to the editable 100-point workspace baseline.'); setError('')
  }
  const recordSession = () => {
    const changed = Object.values(values).reduce((total, scopes) => total + Object.values(scopes).filter((v) => v !== 100).length, 0)
    const item = { id: makeId(), label: `${group} tuning session`, date: new Date().toISOString(), changed }
    const next = [item, ...history].slice(0, 12)
    setHistory(next); writeStore('sensitivity-history', next)
    setNotice('Tuning session added to local history.')
  }
  const comparison = useMemo(() => {
    const a = presets.find((preset) => preset.id === compareA)
    const b = presets.find((preset) => preset.id === compareB)
    if (!a || !b) return null
    const rows = SENSITIVITY_GROUPS.flatMap((g) => SCOPE_KEYS.map((scope) => ({
      key: `${g} / ${scope}`, a: a.values[g][scope], b: b.values[g][scope], delta: b.values[g][scope] - a.values[g][scope],
    })))
    const changed = rows.filter((row) => row.delta !== 0).length
    const meanDelta = rows.reduce((sum, row) => sum + Math.abs(row.delta), 0) / rows.length
    return { rows: rows.filter((row) => row.delta !== 0).slice(0, 8), changed, meanDelta }
  }, [presets, compareA, compareB])

  const exportAll = () => downloadJson('blood-strike-sensitivity.json', { exportedAt: new Date().toISOString(), device, values, presets })
  const copyAll = async () => {
    try { await copyText(JSON.stringify({ device, values }, null, 2)); setNotice('Sensitivity configuration copied as JSON.') }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not copy settings.') }
  }

  return <>
    <PageHeading eyebrow="PLAYER PERFORMANCE / 01" title="Sensitivity Lab" description="Tune every input layer and scope for your device. Treat these values as a starting workspace—not universal or guaranteed recoil settings." action={<button className="btn btn-secondary" onClick={exportAll}><Download size={16} /> Export JSON</button>} />
    <div className="notice notice-warning"><Activity size={16} /><span><b>Calibration note:</b> 6x and 8x scope controls are optional placeholders. Confirm that the scope exists in your current Blood Strike build before tuning it. Always validate changes in the training range.</span></div>
    {(notice || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || notice}</div>}

    <div className="sensitivity-layout">
      <div className="sensitivity-main">
        <Panel>
          <PanelTitle title="Input sensitivity" subtitle="Select an input layer, then tune each optic independently." right={<span className="micro-tag">0–300 SCALE</span>} />
          <div className="segmented-tabs group-tabs">
            {SENSITIVITY_GROUPS.map((item) => <button key={item} className={group === item ? 'selected' : ''} onClick={() => setGroup(item)}>{item}</button>)}
          </div>
          <div className="group-description"><SlidersHorizontal size={17} /><span>{groupNotes[group]}</span></div>
          <div className="scope-grid">
            {SCOPE_KEYS.map((scope) => <div className="scope-control" key={scope}>
              <div className="scope-top"><label>{scope.replace('*', '')}</label><output>{values[group][scope]}</output></div>
              <input type="range" min="0" max="300" step="1" value={values[group][scope]} onChange={(e) => updateValue(scope, Number(e.target.value))} aria-label={`${group} ${scope} sensitivity`} />
              <div className="range-ends"><span>0</span><span>150</span><span>300</span></div>
              {scope.includes('*') && <small className="field-help">Availability varies by build</small>}
            </div>)}
          </div>
          <div className="panel-actions"><button className="btn btn-ghost" onClick={reset}><RotateCcw size={15} /> Reset values</button><button className="btn btn-secondary" onClick={copyAll}><Copy size={15} /> Copy all settings</button><button className="btn btn-primary" onClick={recordSession}><History size={15} /> Record tuning session</button></div>
        </Panel>

        <Panel>
          <PanelTitle title="Device profile" subtitle="Optional context to help you keep different setups organized." />
          <div className="form-grid three-col">
            <Field label="Phone model" value={device.model} placeholder="e.g. Vivo S1 Pro" onChange={(v) => updateDevice('model', v)} />
            <Field label="Screen size" value={device.screen} placeholder="e.g. 6.4 in" onChange={(v) => updateDevice('screen', v)} />
            <SelectField label="Refresh rate" value={device.refreshRate} options={['60 Hz', '90 Hz', '120 Hz', '144 Hz', 'Unknown']} onChange={(v) => updateDevice('refreshRate', v)} />
            <Field label="RAM" value={device.ram} placeholder="e.g. 8 GB" onChange={(v) => updateDevice('ram', v)} />
            <Field label="Processor" value={device.processor} placeholder="Chipset name" onChange={(v) => updateDevice('processor', v)} />
            <Field label="Android version" value={device.android} placeholder="e.g. Android 12" onChange={(v) => updateDevice('android', v)} />
            <SelectField label="Touch input" value={device.touch} options={['Standard', 'High touch sampling', 'Unknown']} onChange={(v) => updateDevice('touch', v as DeviceProfile['touch'])} />
            <SelectField label="Gyroscope" value={device.gyro} options={['Enabled', 'Disabled', 'Unknown']} onChange={(v) => updateDevice('gyro', v as DeviceProfile['gyro'])} />
            <SelectField label="Finger layout" value={device.fingers} options={['2-finger', '3-finger', '4-finger', '5-finger']} onChange={(v) => updateDevice('fingers', v as DeviceProfile['fingers'])} />
            <SelectField label="Playstyle" value={device.playstyle} options={['Aggressive', 'Balanced', 'Defensive', 'Long-range']} onChange={(v) => updateDevice('playstyle', v as DeviceProfile['playstyle'])} />
          </div>
        </Panel>
      </div>

      <div className="sensitivity-side">
        <Panel>
          <PanelTitle title="Save a preset" subtitle={`${presets.length}/5 local presets`} />
          <div className="field-stack"><label className="field-label">Preset name</label><input className="text-input" value={presetName} onChange={(e) => setPresetName(e.target.value)} maxLength={40} placeholder="Name this setup" /></div>
          <button className="btn btn-primary full-width" onClick={savePreset}><Save size={16} /> Save current configuration</button>
          <div className="preset-list">
            {presets.map((preset) => <div className="preset-row" key={preset.id}><button className="preset-load" onClick={() => loadPreset(preset)}><b>{preset.name}</b><small>{preset.device.model || 'Device not specified'} · {new Date(preset.createdAt).toLocaleDateString()}</small></button><button className="icon-button danger" onClick={() => deletePreset(preset.id)} aria-label={`Delete ${preset.name}`}><Trash2 size={15} /></button></div>)}
            {presets.length === 0 && <div className="inline-empty">No saved presets yet. Save your first tuned setup here.</div>}
          </div>
        </Panel>

        <Panel>
          <PanelTitle title="Compare configurations" subtitle="Compare two saved presets scope by scope." />
          <div className="field-stack"><label className="field-label">Preset A</label><select className="text-input" value={compareA} onChange={(e) => setCompareA(e.target.value)}><option value="">Choose preset</option>{presets.map((p) => <option value={p.id} key={p.id}>{p.name}</option>)}</select></div>
          <div className="field-stack"><label className="field-label">Preset B</label><select className="text-input" value={compareB} onChange={(e) => setCompareB(e.target.value)}><option value="">Choose preset</option>{presets.map((p) => <option value={p.id} key={p.id}>{p.name}</option>)}</select></div>
          {comparison ? <div className="compare-result"><div className="compare-stat"><b>{comparison.changed}</b><span>values changed</span></div><div className="compare-stat"><b>{comparison.meanDelta.toFixed(1)}</b><span>mean absolute delta</span></div>{comparison.rows.map((row) => <div className="diff-row" key={row.key}><span>{row.key}</span><b>{row.a} <em>→</em> {row.b}</b></div>)}</div> : <div className="inline-empty">Save at least two presets to compare them.</div>}
        </Panel>

        <Panel>
          <PanelTitle title="Tuning history" subtitle="Saved locally on this browser." />
          {history.length ? <div className="history-list">{history.map((item) => <div className="history-row" key={item.id}><span className="history-dot" /><div><b>{item.label}</b><small>{new Date(item.date).toLocaleString()}</small></div><strong>{item.changed}/48</strong></div>)}</div> : <EmptyState icon={History} title="No sessions recorded" description="Record a tuning session after testing your sensitivity changes." />}
        </Panel>
      </div>
    </div>
  </>
}

function Field({ label, value, placeholder, onChange }: { label: string; value: string; placeholder: string; onChange: (value: string) => void }) {
  return <div className="field-stack"><label className="field-label">{label}</label><input className="text-input" value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} maxLength={80} /></div>
}
function SelectField({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) {
  return <div className="field-stack"><label className="field-label">{label}</label><select className="text-input" value={value} onChange={(e) => onChange(e.target.value)}>{options.map((option) => <option key={option}>{option}</option>)}</select></div>
}
