import { useMemo, useState } from 'react'
import { CalendarCheck, CheckCircle2, ClipboardList, Flame, RotateCcw, Target } from 'lucide-react'
import { TRAINING_MODULES } from '../data/defaults'
import { readStore, upsertTraining } from '../lib/storage'
import { todayKey } from '../lib/utils'
import type { TrainingEntry } from '../types'
import { MetricCard, PageHeading, Panel, PanelTitle } from './Layout'

function getToday() { return readStore<TrainingEntry[]>('training-history', []).find((item) => item.date === todayKey()) ?? { id: todayKey(), date: todayKey(), completed: [], notes: '' } }

export default function TrainingCenter() {
  const [entry, setEntry] = useState<TrainingEntry>(getToday)
  const [history] = useState<TrainingEntry[]>(() => readStore('training-history', []))
  const done = entry.completed.length
  const percent = Math.round(done / TRAINING_MODULES.length * 100)
  const minutes = useMemo(() => TRAINING_MODULES.filter((module) => entry.completed.includes(module.id)).reduce((sum, module) => sum + Number.parseInt(module.duration, 10), 0), [entry.completed])
  const toggle = (id: string) => {
    const next = { ...entry, completed: entry.completed.includes(id) ? entry.completed.filter((item) => item !== id) : [...entry.completed, id] }
    setEntry(next); upsertTraining(next)
  }
  const saveNotes = (notes: string) => { const next = { ...entry, notes }; setEntry(next); upsertTraining(next) }
  const reset = () => { const next = { ...entry, completed: [] }; setEntry(next); upsertTraining(next) }

  return <>
    <PageHeading eyebrow="SKILL DEVELOPMENT / 07" title="Aim Training Center" description="A repeatable practice loop for fundamentals, consistency and deliberate improvement." action={<span className="date-chip"><CalendarCheck size={15} /> {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}</span>} />
    <div className="metric-grid three-metrics"><MetricCard label="Today's modules" value={`${done}/${TRAINING_MODULES.length}`} detail="Modules checked off" icon={ClipboardList} /><MetricCard label="Practice time" value={`${minutes} min`} detail="Estimated completed time" icon={Flame} accent="purple" /><MetricCard label="Daily completion" value={`${percent}%`} detail="Progress saved on this device" icon={Target} accent="green" /></div>
    <Panel>
      <div className="training-progress-head"><div><h3>Today's training plan</h3><p>Complete each module after practicing it in-game.</p></div><button className="btn btn-ghost btn-small" onClick={reset}><RotateCcw size={14} /> Reset today</button></div>
      <div className="progress-track"><span style={{ width: `${percent}%` }} /></div>
      <div className="training-list">{TRAINING_MODULES.map((module, index) => <label className={`training-item ${entry.completed.includes(module.id) ? 'completed' : ''}`} key={module.id}><input type="checkbox" checked={entry.completed.includes(module.id)} onChange={() => toggle(module.id)} /><span className="training-index">{String(index + 1).padStart(2, '0')}</span><span className="training-copy"><b>{module.title}</b><small>{module.detail}</small></span><span className="training-duration">{module.duration}</span>{entry.completed.includes(module.id) && <CheckCircle2 className="completed-check" size={17} />}</label>)}</div>
    </Panel>
    <Panel><PanelTitle title="Skill notes" subtitle="Record what worked, what felt inconsistent, and what to test next." /><textarea className="text-input training-notes" value={entry.notes} onChange={(e) => saveNotes(e.target.value)} maxLength={1200} placeholder="Example: 3x tracking felt over-sensitive; retest one step lower after warm-up…" /><div className="field-footer">{entry.notes.length}/1200 · Auto-saved locally</div></Panel>
    <Panel><PanelTitle title="Recent practice history" subtitle="Past daily checklists saved in this browser." />{history.length ? <div className="history-grid">{history.slice(0, 7).map((item) => <div className="history-day" key={item.id}><span>{new Date(`${item.date}T12:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span><b>{item.completed.length}/{TRAINING_MODULES.length}</b><small>modules</small></div>)}</div> : <div className="inline-empty">Your completed practice days will appear here.</div>}</Panel>
  </>
}
