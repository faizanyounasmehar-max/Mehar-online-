import { useMemo, useState } from 'react'
import { Crosshair, Download, Layers3, Plus, Save, Share2, Trash2 } from 'lucide-react'
import { addLoadout, readStore, writeStore } from '../lib/storage'
import { copyText, downloadJson, makeId } from '../lib/utils'
import type { SavedLoadout } from '../types'
import { EmptyState, PageHeading, Panel, PanelTitle } from './Layout'

const blank = { name: '', primary: '', secondary: '', optics: '', attachments: '', equipment: '', operator: '', playstyle: 'Balanced', notes: '' }

export default function LoadoutBuilder() {
  const [form, setForm] = useState(blank)
  const [saved, setSaved] = useState<SavedLoadout[]>(() => readStore('loadouts', []))
  const [selected, setSelected] = useState<string[]>([])
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')
  const update = (key: keyof typeof blank, value: string) => setForm((current) => ({ ...current, [key]: value }))

  const save = () => {
    setNotice(''); setError('')
    if (!form.name.trim() || !form.primary.trim()) { setError('Give this loadout a name and enter a primary weapon.'); return }
    const item: SavedLoadout = { ...form, id: makeId(), createdAt: new Date().toISOString() }
    const next = addLoadout(item)
    setSaved(next); setForm(blank); setNotice('Loadout saved locally on this device.')
  }
  const remove = (id: string) => {
    const next = saved.filter((item) => item.id !== id)
    setSaved(next); writeStore('loadouts', next); setSelected((current) => current.filter((entry) => entry !== id))
  }
  const toggleCompare = (id: string) => setSelected((current) => current.includes(id) ? current.filter((entry) => entry !== id) : current.length >= 2 ? [current[1], id] : [...current, id])
  const comparison = useMemo(() => selected.map((id) => saved.find((item) => item.id === id)).filter((item): item is SavedLoadout => Boolean(item)), [selected, saved])
  const share = async (item: SavedLoadout) => {
    try { await copyText(JSON.stringify(item, null, 2)); setNotice(`Copied ${item.name} as shareable JSON.`) }
    catch (err) { setError(err instanceof Error ? err.message : 'Unable to copy loadout.') }
  }

  return <>
    <PageHeading eyebrow="CONFIGURATION WORKSHOP / 04" title="Loadout Builder" description="Draft and compare weapon setups. Names and attachment combinations are user-entered until a verified in-game catalog is connected." action={<button className="btn btn-secondary" onClick={() => downloadJson('blood-strike-loadouts.json', saved)}><Download size={15} /> Export library</button>} />
    {(notice || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || notice}</div>}
    <div className="content-grid two-up">
      <Panel>
        <PanelTitle title="Create a loadout" subtitle="Build a setup around the role you want to play." right={<span className="micro-tag">LOCAL DRAFT</span>} />
        <div className="form-grid two-col">
          <Field label="Loadout name *" value={form.name} placeholder="e.g. Urban entry setup" onChange={(v) => update('name', v)} />
          <Select label="Playstyle" value={form.playstyle} options={['Aggressive', 'Balanced', 'Defensive', 'Long-range', 'Close-range', 'Support']} onChange={(v) => update('playstyle', v)} />
          <Field label="Primary weapon *" value={form.primary} placeholder="Enter in-game weapon name" onChange={(v) => update('primary', v)} />
          <Field label="Secondary weapon" value={form.secondary} placeholder="Enter secondary weapon" onChange={(v) => update('secondary', v)} />
          <Field label="Optics" value={form.optics} placeholder="Optic / scope" onChange={(v) => update('optics', v)} />
          <Field label="Tactical equipment" value={form.equipment} placeholder="Enter equipment" onChange={(v) => update('equipment', v)} />
          <Field label="Attachments" value={form.attachments} placeholder="Comma-separated attachments" onChange={(v) => update('attachments', v)} />
          <Field label="Operator" value={form.operator} placeholder="Operator name" onChange={(v) => update('operator', v)} />
          <div className="field-stack span-2"><label className="field-label">Notes / test results</label><textarea className="text-input text-area" value={form.notes} onChange={(e) => update('notes', e.target.value)} placeholder="Record recoil feel, range tests, or situational notes…" maxLength={500} /></div>
        </div>
        <div className="panel-actions"><button className="btn btn-primary" onClick={save}><Save size={16} /> Save loadout</button><button className="btn btn-ghost" onClick={() => setForm(blank)}><Plus size={15} /> Clear form</button></div>
        <p className="subtle-note">This builder stores your own descriptions. It does not validate weapon or attachment compatibility.</p>
      </Panel>
      <Panel>
        <PanelTitle title="Loadout library" subtitle={`${saved.length} saved locally`} />
        {saved.length ? <div className="saved-loadouts">{saved.map((item) => <div className="loadout-card" key={item.id}>
          <div className="loadout-card-top"><div className="loadout-emblem"><Crosshair size={18} /></div><div className="loadout-info"><b>{item.name}</b><small>{item.playstyle} · {new Date(item.createdAt).toLocaleDateString()}</small></div><button className="icon-button danger" onClick={() => remove(item.id)} aria-label={`Delete ${item.name}`}><Trash2 size={15} /></button></div>
          <div className="loadout-weapons"><div><small>PRIMARY</small><b>{item.primary}</b></div><div><small>SECONDARY</small><b>{item.secondary || 'Not set'}</b></div></div>
          <div className="loadout-meta"><span>{item.optics || 'No optic specified'}</span><span>{item.operator || 'No operator specified'}</span></div>
          <div className="loadout-actions"><label className="compare-check"><input type="checkbox" checked={selected.includes(item.id)} onChange={() => toggleCompare(item.id)} /> Compare</label><button className="text-action" onClick={() => share(item)}><Share2 size={14} /> Share JSON</button></div>
        </div>)}</div> : <EmptyState icon={Layers3} title="Your library is empty" description="Create your first custom loadout to start building a personal library." />}
      </Panel>
    </div>
    <Panel className="compare-panel"><PanelTitle title="Side-by-side comparison" subtitle="Select up to two cards in the library to compare their setup fields." />
      {comparison.length === 2 ? <div className="compare-table">{(['primary', 'secondary', 'optics', 'attachments', 'equipment', 'operator', 'playstyle', 'notes'] as const).map((key) => <div className="compare-line" key={key}><span>{key}</span><b>{comparison[0][key] || '—'}</b><b>{comparison[1][key] || '—'}</b></div>)}</div> : <div className="inline-empty">Choose two saved loadouts above. {comparison.length}/2 selected.</div>}
    </Panel>
  </>
}
function Field({ label, value, placeholder, onChange }: { label: string; value: string; placeholder: string; onChange: (v: string) => void }) { return <div className="field-stack"><label className="field-label">{label}</label><input className="text-input" value={value} maxLength={100} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} /></div> }
function Select({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) { return <div className="field-stack"><label className="field-label">{label}</label><select className="text-input" value={value} onChange={(e) => onChange(e.target.value)}>{options.map((o) => <option key={o}>{o}</option>)}</select></div> }

