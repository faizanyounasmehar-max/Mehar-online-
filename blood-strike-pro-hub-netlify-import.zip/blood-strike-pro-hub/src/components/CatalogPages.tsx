import { useEffect, useMemo, useState } from 'react'
import { Search, ShieldCheck, Crosshair, Database, ExternalLink, UserRound } from 'lucide-react'
import { isSupabaseConfigured, supabase } from '../lib/supabase'
import { EmptyState, PageHeading, Panel } from './Layout'

type Weapon = {
  id: string; name: string; category: string; image_url: string | null; damage: number | null;
  fire_rate: number | null; effective_range: string | null; recoil: string | null; reload_time: string | null;
  attachments: string[] | null; strengths: string | null; weaknesses: string | null; playstyle: string | null;
  suggested_scope: string | null; community_rating: number | null; verified: boolean; source_url: string | null;
}
type Operator = {
  id: string; name: string; role: string | null; ability_description: string | null;
  mobility: number | null; defense: number | null; utility: number | null; playstyle: string | null;
  team_combinations: string | null; image_url: string | null; verified: boolean; source_url: string | null;
}

const weaponCategories = ['All', 'Assault Rifles', 'SMGs', 'LMGs', 'DMRs', 'Sniper Rifles', 'Shotguns']

export function WeaponsPage() {
  const [weapons, setWeapons] = useState<Weapon[]>([])
  const [category, setCategory] = useState('All')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(isSupabaseConfigured)
  const [error, setError] = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    let live = true
    if (!supabase) return
    supabase.from('weapons').select('*').eq('verified', true).order('name').then(({ data, error: queryError }) => {
      if (!live) return
      if (queryError) setError(queryError.message)
      else setWeapons((data ?? []) as Weapon[])
      setLoading(false)
    })
    return () => { live = false }
  }, [])

  const filtered = useMemo(() => weapons.filter((weapon) =>
    (category === 'All' || weapon.category === category) && `${weapon.name} ${weapon.category}`.toLowerCase().includes(search.toLowerCase()),
  ), [weapons, category, search])

  return <>
    <PageHeading eyebrow="REFERENCE DATABASE / 03" title="Weapon Database" description="A searchable reference for Blood Strike Mobile weapons. Only records marked verified by an administrator are displayed." />
    <Panel>
      <div className="catalog-toolbar"><div className="catalog-search"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search verified weapons…" /></div><span className="verified-tag"><ShieldCheck size={14} /> VERIFIED RECORDS ONLY</span></div>
      <div className="filter-row">{weaponCategories.map((item) => <button className={`filter-chip ${category === item ? 'active' : ''}`} onClick={() => setCategory(item)} key={item}>{item}</button>)}</div>
      {loading ? <div className="loading-line">Loading verified catalog…</div> : error ? <div className="notice notice-error">Could not load the weapon catalog: {error}</div> : filtered.length ? <div className="weapon-grid">{filtered.map((weapon) => <article className={`weapon-card ${expanded === weapon.id ? 'expanded' : ''}`} key={weapon.id}>
        <div className="weapon-visual">{weapon.image_url ? <img src={weapon.image_url} alt={`${weapon.name} weapon`} loading="lazy" /> : <div className="weapon-placeholder"><Crosshair size={32} /><span>WEAPON FILE</span></div>}<span className="weapon-category">{weapon.category}</span></div>
        <div className="weapon-card-body"><div className="weapon-title-row"><h3>{weapon.name}</h3><ShieldCheck size={15} className="verified-icon" /></div>
          <div className="weapon-spec-grid"><Spec label="Damage" value={weapon.damage} /><Spec label="Fire rate" value={weapon.fire_rate} /><Spec label="Range" value={weapon.effective_range} /><Spec label="Reload" value={weapon.reload_time} /></div>
          <div className="weapon-trait"><small>RECOIL PROFILE</small><b>{weapon.recoil || 'Not published'}</b></div>
          {expanded === weapon.id && <div className="weapon-details"><p><b>Strengths:</b> {weapon.strengths || 'Not published'}</p><p><b>Limitations:</b> {weapon.weaknesses || 'Not published'}</p><p><b>Attachments:</b> {weapon.attachments?.join(', ') || 'Not published'}</p><p><b>Suggested scope:</b> {weapon.suggested_scope || 'Not published'}</p><p><b>Playstyle:</b> {weapon.playstyle || 'Not published'}</p>{weapon.community_rating != null && <p><b>Community rating:</b> {weapon.community_rating.toFixed(1)} / 5</p>}</div>}
          <div className="weapon-card-actions"><button className="text-action" onClick={() => setExpanded(expanded === weapon.id ? null : weapon.id)}>{expanded === weapon.id ? 'Hide details' : 'Full profile'}</button>{weapon.source_url && <a className="text-action" href={weapon.source_url} target="_blank" rel="noreferrer">Source <ExternalLink size={13} /></a>}</div>
        </div>
      </article>)}</div> : <EmptyState icon={Database} title={isSupabaseConfigured ? 'No verified weapon records yet' : 'Connect the weapon database'} description={isSupabaseConfigured ? 'The catalog is empty. Add sourced records in the admin workflow and mark them verified before publishing.' : 'Add your Supabase project credentials and run the included SQL schema. The site intentionally does not invent weapon stats or attachment compatibility.'} />}
    </Panel>
    <div className="notice notice-info"><Database size={16} /><span>Damage, fire rate, range, reload, recoil and community ratings are database-driven. Missing fields are shown as “Not published”, never estimated.</span></div>
  </>
}

export function OperatorsPage() {
  const [items, setItems] = useState<Operator[]>([])
  const [loading, setLoading] = useState(isSupabaseConfigured)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  useEffect(() => {
    let live = true
    if (!supabase) return
    supabase.from('operators').select('*').eq('verified', true).order('name').then(({ data, error: queryError }) => {
      if (!live) return
      if (queryError) setError(queryError.message)
      else setItems((data ?? []) as Operator[])
      setLoading(false)
    })
    return () => { live = false }
  }, [])
  const filtered = items.filter((item) => `${item.name} ${item.role ?? ''}`.toLowerCase().includes(search.toLowerCase()))
  return <>
    <PageHeading eyebrow="TACTICAL PERSONNEL / 03B" title="Operator Database" description="Verified operator roles, abilities and team utility. Unpublished values remain blank until supported by a source." />
    <Panel><div className="catalog-toolbar"><div className="catalog-search"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search operators…" /></div><span className="verified-tag"><ShieldCheck size={14} /> VERIFIED ONLY</span></div>
      {loading ? <div className="loading-line">Loading operator records…</div> : error ? <div className="notice notice-error">Could not load operators: {error}</div> : filtered.length ? <div className="operator-grid">{filtered.map((item) => <article className="operator-card" key={item.id}><div className="operator-avatar">{item.image_url ? <img src={item.image_url} alt={item.name} loading="lazy" /> : <UserRound size={32} />}</div><div className="operator-body"><div className="operator-head"><h3>{item.name}</h3><span>{item.role || 'Role not published'}</span></div><p>{item.ability_description || 'Ability description not published.'}</p><div className="operator-bars">{[['Mobility', item.mobility], ['Defense', item.defense], ['Utility', item.utility]].map(([label, val]) => <div key={String(label)} className="operator-bar-row"><span>{label}</span><b>{val == null ? '—' : val}</b>{val != null && <i><em style={{ width: `${Math.min(100, Math.max(0, Number(val)))}%` }} /></i>}</div>)}</div><small>Playstyle: {item.playstyle || 'Not published'}</small>{item.team_combinations && <small>Team synergy: {item.team_combinations}</small>}{item.source_url && <a href={item.source_url} target="_blank" rel="noreferrer" className="text-action">Open source <ExternalLink size={13} /></a>}</div></article>)}</div> : <EmptyState icon={UserRound} title="No verified operator records" description="Connect Supabase and populate the operators table with sourced details. Operator abilities and ratings are not fabricated in this starter project." />}
    </Panel>
  </>
}

function Spec({ label, value }: { label: string; value: string | number | null }) { return <div><small>{label}</small><b>{value == null || value === '' ? '—' : value}</b></div> }
