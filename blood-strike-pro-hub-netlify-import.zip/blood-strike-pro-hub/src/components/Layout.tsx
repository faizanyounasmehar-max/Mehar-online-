import { useMemo, useState, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity, Bot, ChevronDown, CircleHelp, Crosshair, Layers3, LayoutDashboard,
  Menu, PanelsTopLeft, PlaySquare, Search, Settings2, Shield, Smartphone,
  SlidersHorizontal, Target, Trophy, UserRound, Users, X, Mail,
} from 'lucide-react'
import { NAV_ITEMS } from '../data/defaults'
import type { Profile } from '../lib/supabase'

const iconMap = {
  LayoutDashboard, SlidersHorizontal, Crosshair, Layers3, PanelsTopLeft,
  Smartphone, Target, Trophy, PlaySquare, Bot, Users, UserRound,
}

const extraNav = [
  { id: 'profile', label: 'Player Profile', icon: UserRound },
  { id: 'admin', label: 'Admin Console', icon: Shield },
  { id: 'about', label: 'About & Policies', icon: CircleHelp },
  { id: 'contact', label: 'Contact Support', icon: Mail },
]

type Props = {
  active: string
  onNavigate: (page: string) => void
  profile: Profile | null
  children: ReactNode
}

export function Layout({ active, onNavigate, profile, children }: Props) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false)
  const allNav = useMemo(() => [
    ...NAV_ITEMS.map((item) => ({ ...item, icon: iconMap[item.icon as keyof typeof iconMap] })),
    ...extraNav,
  ], [])
  const filtered = allNav.filter((item) => item.label.toLowerCase().includes(search.toLowerCase()))
  const current = allNav.find((item) => item.id === active)?.label ?? 'Overview'
  const go = (page: string) => {
    onNavigate(page)
    setMenuOpen(false)
    setSearch('')
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-lockup" onClick={() => go('overview')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') go('overview') }} role="button" tabIndex={0}>
          <div className="brand-mark"><Crosshair size={23} strokeWidth={2.5} /></div>
          <div><strong>BLOOD STRIKE</strong><span>PRO HUB <i> / MOBILE</i></span></div>
          <button className="icon-button sidebar-close" onClick={(event) => { event.stopPropagation(); setMenuOpen(false) }} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="sidebar-label">COMMAND MENU</div>
        <nav className="side-nav" aria-label="Main navigation">
          {filtered.map((item) => {
            const Icon = item.icon
            return <button key={item.id} className={`nav-item ${active === item.id ? 'active' : ''}`} onClick={() => go(item.id)}>
              <Icon size={18} strokeWidth={1.8} /><span>{item.label}</span>{active === item.id && <span className="nav-active-dot" />}
            </button>
          })}
          {filtered.length === 0 && <div className="nav-empty">No sections found</div>}
        </nav>
        <div className="sidebar-bottom">
          <div className="system-card">
            <div className="system-top"><span className="live-dot" /> SYSTEM STATUS</div>
            <strong>LOCAL TOOLS READY</strong>
            <small>Cloud features depend on setup</small>
          </div>
          <button className="nav-item" onClick={() => go('about')}><Settings2 size={18} /><span>Settings & legal</span></button>
          <div className="sidebar-foot">Independent community companion<br />Not affiliated with NetEase</div>
        </div>
      </aside>

      <div className="main-column">
        <header className="topbar">
          <button className="icon-button mobile-menu" aria-label="Open navigation" onClick={() => setMenuOpen(true)}><Menu size={21} /></button>
          <div className="breadcrumb"><span>PRO HUB</span><b>/</b><strong>{current}</strong></div>
          <div className="topbar-actions">
            {mobileSearchOpen ? <div className="mobile-search-wrap"><Search size={16} /><input autoFocus value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && filtered[0]) go(filtered[0].id) }} placeholder="Find a section" /></div> : null}
            <button className="icon-button search-toggle" aria-label="Search sections" onClick={() => setMobileSearchOpen((value) => !value)}><Search size={18} /></button>
            <button className="profile-chip" onClick={() => go('profile')}>
              <span className="avatar-small">{profile?.username?.slice(0, 1).toUpperCase() ?? 'P'}</span>
              <span className="profile-chip-text"><b>{profile?.username ?? 'Player'}</b><small>{profile?.role === 'admin' ? 'ADMIN' : 'GUEST MODE'}</small></span>
              <ChevronDown size={14} />
            </button>
          </div>
        </header>
        <div className="global-search-bar">
          <Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && filtered[0]) go(filtered[0].id) }} placeholder="Quick navigate — search tools, weapons, training..." />
          <kbd>ENTER</kbd>
        </div>
        <main className="main-content">
          <AnimatePresence mode="wait">
            <motion.div key={active} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.18 }}>
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
        <footer className="site-footer"><span>© {new Date().getFullYear()} BLOOD STRIKE PRO HUB</span><span>INDEPENDENT • COMMUNITY BUILT • MOBILE FIRST</span></footer>
      </div>

      <div className="mobile-bottom-nav">
        {[['overview', LayoutDashboard, 'Home'], ['sensitivity', SlidersHorizontal, 'Tune'], ['loadouts', Layers3, 'Build'], ['training', Target, 'Train']].map(([id, Icon, label]) => {
          const key = id as string
          const IconComp = Icon as typeof LayoutDashboard
          return <button key={key} className={active === key ? 'active' : ''} onClick={() => go(key)}><IconComp size={19} /><span>{label as string}</span></button>
        })}
        <button onClick={() => setMenuOpen(true)}><Menu size={19} /><span>More</span></button>
      </div>
      {menuOpen && <button className="mobile-overlay" aria-label="Close menu" onClick={() => setMenuOpen(false)} />}
    </div>
  )
}

export function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow"><span />{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action && <div className="heading-action">{action}</div>}</div>
}

export function Panel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>{children}</section>
}

export function PanelTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return <div className="panel-title"><div><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}</div>{right}</div>
}

export function EmptyState({ icon: Icon = Activity, title, description, action }: { icon?: typeof Activity; title: string; description: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={24} /></div><strong>{title}</strong><p>{description}</p>{action}</div>
}

export function MetricCard({ label, value, detail, icon: Icon, accent = 'red' }: { label: string; value: string; detail: string; icon: typeof Activity; accent?: 'red' | 'purple' | 'green' }) {
  return <div className={`metric-card accent-${accent}`}><div className="metric-top"><span>{label}</span><div><Icon size={18} /></div></div><strong>{value}</strong><small>{detail}</small></div>
}
