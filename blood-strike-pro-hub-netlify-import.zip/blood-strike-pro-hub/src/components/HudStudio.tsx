import { useState, type CSSProperties } from 'react'
import { Copy, Download, Eye, Move, Save, Trash2 } from 'lucide-react'
import { addHud, readStore, writeStore } from '../lib/storage'
import { copyText, downloadJson, makeId } from '../lib/utils'
import type { DeviceProfile, SavedHud } from '../types'
import { EmptyState, PageHeading, Panel, PanelTitle } from './Layout'

export default function HudStudio() {
  const [fingers, setFingers] = useState<DeviceProfile['fingers']>('3-finger')
  const [buttonSize, setButtonSize] = useState(62)
  const [opacity, setOpacity] = useState(78)
  const [layout, setLayout] = useState<SavedHud['layout']>('balanced')
  const [name, setName] = useState('My HUD layout')
  const [saved, setSaved] = useState<SavedHud[]>(() => readStore('hud-presets', []))
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')

  const save = () => {
    setError(''); setNotice('')
    if (!name.trim()) { setError('Enter a name for the HUD layout.'); return }
    try {
      const next = addHud({ id: makeId(), name: name.trim(), fingers, buttonSize, opacity, layout, createdAt: new Date().toISOString() })
      setSaved(next); setNotice('HUD layout saved locally.')
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not save layout.') }
  }
  const load = (item: SavedHud) => { setName(item.name); setFingers(item.fingers); setButtonSize(item.buttonSize); setOpacity(item.opacity); setLayout(item.layout); setNotice(`${item.name} loaded.`) }
  const remove = (id: string) => { const next = saved.filter((item) => item.id !== id); setSaved(next); writeStore('hud-presets', next) }
  const current = { name, fingers, buttonSize, opacity, layout }
  const share = async () => { try { await copyText(JSON.stringify(current, null, 2)); setNotice('HUD configuration copied as JSON.') } catch { setError('Clipboard access is unavailable.') } }
  const spots = layout === 'movement' ? 'movement' : layout === 'aim' ? 'aim' : 'balanced'

  return <>
    <PageHeading eyebrow="CONTROL CONFIGURATION / 05" title="HUD Studio" description="Plan a finger layout and tune visual sizing. The preview is a planning aid, not a direct in-game HUD injector." action={<button className="btn btn-secondary" onClick={() => downloadJson('blood-strike-hud.json', { ...current, exportedAt: new Date().toISOString() })}><Download size={15} /> Export layout</button>} />
    {(notice || error) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`}>{error || notice}</div>}
    <div className="content-grid two-up">
      <Panel>
        <PanelTitle title="Layout preview" subtitle="Controls are illustrative. Recreate their positions in the game's HUD editor." right={<span className="micro-tag"><Eye size={12} /> PREVIEW</span>} />
        <div className={`hud-preview hud-${spots}`} style={{ '--hud-size': `${buttonSize}px`, '--hud-opacity': opacity / 100 } as CSSProperties}>
          <div className="hud-safe">BLOOD STRIKE · LAYOUT MOCKUP</div>
          <div className="hud-stick"><span /></div>
          <div className="hud-fire">FIRE</div><div className="hud-aim">AIM</div><div className="hud-jump">↗</div><div className="hud-crouch">↓</div><div className="hud-reload">↻</div><div className="hud-grenade">◎</div><div className="hud-swap">⇄</div>
          <div className="hud-map"><span /> MINI MAP</div>
          <div className="hud-bottom-label">{fingers.toUpperCase()} CONTROL PRESET</div>
        </div>
        <div className="hud-legend"><span><i className="legend-red" /> Fire / combat</span><span><i className="legend-purple" /> Movement / utility</span><span><i className="legend-white" /> Aim / actions</span></div>
      </Panel>
      <Panel>
        <PanelTitle title="Customize controls" subtitle="Adjust the preview, then save a configuration." />
        <div className="field-stack"><label className="field-label">HUD name</label><input className="text-input" value={name} onChange={(e) => setName(e.target.value)} maxLength={40} /></div>
        <div className="field-stack"><label className="field-label">Finger layout</label><div className="choice-grid four">{(['2-finger', '3-finger', '4-finger', '5-finger'] as const).map((option) => <button key={option} className={`choice-card ${fingers === option ? 'selected' : ''}`} onClick={() => setFingers(option)}><b>{option.split('-')[0]}</b><small>Fingers</small></button>)}</div></div>
        <div className="field-stack"><div className="range-label"><label className="field-label">Button size</label><output>{buttonSize}%</output></div><input className="full-range" type="range" min="40" max="100" value={buttonSize} onChange={(e) => setButtonSize(Number(e.target.value))} /></div>
        <div className="field-stack"><div className="range-label"><label className="field-label">Button opacity</label><output>{opacity}%</output></div><input className="full-range" type="range" min="20" max="100" value={opacity} onChange={(e) => setOpacity(Number(e.target.value))} /></div>
        <div className="field-stack"><label className="field-label">Control emphasis</label><div className="segmented-tabs"><button className={layout === 'balanced' ? 'selected' : ''} onClick={() => setLayout('balanced')}>Balanced</button><button className={layout === 'movement' ? 'selected' : ''} onClick={() => setLayout('movement')}>Movement</button><button className={layout === 'aim' ? 'selected' : ''} onClick={() => setLayout('aim')}>Aim focus</button></div></div>
        <div className="panel-actions"><button className="btn btn-primary" onClick={save}><Save size={15} /> Save layout</button><button className="btn btn-secondary" onClick={share}><Copy size={15} /> Copy / share</button></div>
        <p className="subtle-note"><Move size={13} /> Drag-and-drop direct game integration is not available. Use this visual plan as a reference while editing your in-game HUD.</p>
      </Panel>
    </div>
    <Panel><PanelTitle title="Saved HUD layouts" subtitle={`${saved.length} layouts on this device`} />{saved.length ? <div className="saved-hud-grid">{saved.map((item) => <div className="saved-hud-card" key={item.id}><div><b>{item.name}</b><small>{item.fingers} · {item.layout} · size {item.buttonSize}%</small></div><div className="card-buttons"><button className="text-action" onClick={() => load(item)}>Load</button><button className="icon-button danger" onClick={() => remove(item.id)} aria-label={`Delete ${item.name}`}><Trash2 size={14} /></button></div></div>)}</div> : <EmptyState title="No HUD layouts saved" description="Save your first preview configuration to keep it here." />}</Panel>
  </>
}
