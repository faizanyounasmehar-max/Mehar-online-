import { useCallback, useEffect, useState, type ReactNode } from 'react'
import { Layout } from './components/Layout'
import SensitivityLab from './components/SensitivityLab'
import LoadoutBuilder from './components/LoadoutBuilder'
import HudStudio from './components/HudStudio'
import TrainingCenter from './components/TrainingCenter'
import AssistantPage from './components/AssistantPage'
import { WeaponsPage, OperatorsPage } from './components/CatalogPages'
import { AboutPage, AdminPage, ContactPage, ProfilePage } from './components/AccountPages'
import { CommunityPage, DeviceCenter, MediaPage, NotFoundPage, OverviewPage, TournamentsPage } from './components/GeneralPages'
import { isSupabaseConfigured, supabase, type Profile } from './lib/supabase'

export default function App() {
  const [active, setActive] = useState(() => window.location.hash.replace('#', '') || (window.location.pathname === '/' ? 'overview' : 'not-found'))
  const [profile, setProfile] = useState<Profile | null>(null)

  const refreshProfile = useCallback(async () => {
    if (!supabase) { setProfile(null); return }
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) { setProfile(null); return }
    const { data, error } = await supabase.from('profiles').select('id,username,avatar_url,role,created_at').eq('id', user.id).maybeSingle()
    if (!error && data) setProfile(data as Profile)
    else setProfile({ id: user.id, username: user.user_metadata?.username ?? user.email?.split('@')[0] ?? 'Player', avatar_url: null, role: 'player' })
  }, [])

  useEffect(() => {
    if (!supabase) return
    void refreshProfile()
    let refreshTimer: ReturnType<typeof setTimeout> | undefined
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      if (refreshTimer) clearTimeout(refreshTimer)
      refreshTimer = setTimeout(() => { void refreshProfile() }, 0)
    })
    return () => { if (refreshTimer) clearTimeout(refreshTimer); subscription.unsubscribe() }
  }, [refreshProfile])

  const navigate = (page: string) => {
    setActive(page)
    window.history.replaceState(null, '', `#${page}`)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  let page: ReactNode
  switch (active) {
    case 'sensitivity': page = <SensitivityLab />; break
    case 'weapons': page = <WeaponsPage />; break
    case 'operators': page = <OperatorsPage />; break
    case 'loadouts': page = <LoadoutBuilder />; break
    case 'hud': page = <HudStudio />; break
    case 'device': page = <DeviceCenter />; break
    case 'training': page = <TrainingCenter />; break
    case 'tournaments': page = <TournamentsPage onSignIn={() => navigate('profile')} />; break
    case 'media': page = <MediaPage />; break
    case 'assistant': page = <AssistantPage />; break
    case 'community': page = <CommunityPage onSignIn={() => navigate('profile')} />; break
    case 'profile': page = <ProfilePage profile={profile} onProfileChange={refreshProfile} />; break
    case 'admin': page = <AdminPage profile={profile} />; break
    case 'about': page = <AboutPage />; break
    case 'contact': page = <ContactPage onSignIn={() => navigate('profile')} />; break
    case 'overview': page = <OverviewPage onNavigate={navigate} />; break
    case 'not-found':
    default: page = <NotFoundPage onHome={() => navigate('overview')} />
  }

  return <Layout active={active} onNavigate={navigate} profile={profile}>{!isSupabaseConfigured && active !== 'profile' && <div className="config-ribbon"><span className="config-ribbon-dot" /> LOCAL MODE <span>— Add Supabase keys to enable cloud accounts, shared catalogs and community features.</span><button onClick={() => navigate('profile')}>Configure <span>→</span></button></div>}{page}</Layout>
}
