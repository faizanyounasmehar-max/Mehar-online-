import { SENSITIVITY_GROUPS, SCOPE_KEYS, type DeviceProfile, type SensitivityValues } from '../types'

export const makeDefaultSensitivity = (): SensitivityValues =>
  Object.fromEntries(
    SENSITIVITY_GROUPS.map((group) => [group, Object.fromEntries(SCOPE_KEYS.map((scope) => [scope, 100]))]),
  ) as SensitivityValues

export const DEFAULT_DEVICE: DeviceProfile = {
  model: '',
  screen: '',
  refreshRate: '60 Hz',
  ram: '',
  processor: '',
  android: '',
  touch: 'Unknown',
  gyro: 'Unknown',
  fingers: '3-finger',
  playstyle: 'Balanced',
}

export const TRAINING_MODULES = [
  { id: 'crosshair', title: 'Crosshair placement', detail: 'Keep your aim at likely opponent head-height before exposing yourself.', duration: '5 min' },
  { id: 'tracking', title: 'Target tracking', detail: 'Track a moving target smoothly without snapping past it.', duration: '5 min' },
  { id: 'recoil', title: 'Recoil control', detail: 'Use short, repeatable bursts and observe the pattern before correcting.', duration: '7 min' },
  { id: 'close', title: 'Close-range control', detail: 'Practice controlled hipfire-to-ADS transitions at close distance.', duration: '5 min' },
  { id: 'mid', title: 'Mid-range precision', detail: 'Prioritize first-shot placement and measured follow-up shots.', duration: '5 min' },
  { id: 'long', title: 'Long-range discipline', detail: 'Settle your aim, take deliberate shots, and avoid unnecessary movement.', duration: '5 min' },
  { id: 'gyro', title: 'Gyroscope calibration', detail: 'Make small corrections while keeping your wrist relaxed.', duration: '5 min' },
  { id: 'movement', title: 'Movement & positioning', detail: 'Use cover, avoid predictable peeks, and plan your next position.', duration: '5 min' },
]

export const NAV_ITEMS = [
  { id: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
  { id: 'sensitivity', label: 'Sensitivity Lab', icon: 'SlidersHorizontal' },
  { id: 'weapons', label: 'Weapon DB', icon: 'Crosshair' },
  { id: 'operators', label: 'Operator DB', icon: 'UserRound' },
  { id: 'loadouts', label: 'Loadout Builder', icon: 'Layers3' },
  { id: 'hud', label: 'HUD Studio', icon: 'PanelsTopLeft' },
  { id: 'device', label: 'Device Center', icon: 'Smartphone' },
  { id: 'training', label: 'Aim Training', icon: 'Target' },
  { id: 'tournaments', label: 'Esports', icon: 'Trophy' },
  { id: 'media', label: 'Media Center', icon: 'PlaySquare' },
  { id: 'assistant', label: 'AI Assistant', icon: 'Bot' },
  { id: 'community', label: 'Community', icon: 'Users' },
]
