export const SCOPE_KEYS = [
  'Hipfire',
  'Red Dot / Holo',
  'Tactical 1.5x',
  '2x Scope',
  '3x Scope',
  '4x Scope',
  '6x Scope*',
  '8x Scope*',
] as const
export type ScopeKey = (typeof SCOPE_KEYS)[number]

export const SENSITIVITY_GROUPS = [
  'Camera',
  'ADS',
  'Firing',
  'Gyro Camera',
  'Gyro ADS',
  'Gyro Firing',
] as const
export type SensitivityGroup = (typeof SENSITIVITY_GROUPS)[number]

export type SensitivityValues = Record<SensitivityGroup, Record<ScopeKey, number>>

export interface DeviceProfile {
  model: string
  screen: string
  refreshRate: string
  ram: string
  processor: string
  android: string
  touch: 'Standard' | 'High touch sampling' | 'Unknown'
  gyro: 'Enabled' | 'Disabled' | 'Unknown'
  fingers: '2-finger' | '3-finger' | '4-finger' | '5-finger'
  playstyle: 'Aggressive' | 'Balanced' | 'Defensive' | 'Long-range'
}

export interface SensitivityPreset {
  id: string
  name: string
  createdAt: string
  device: DeviceProfile
  values: SensitivityValues
}

export interface SavedLoadout {
  id: string
  name: string
  primary: string
  secondary: string
  optics: string
  attachments: string
  equipment: string
  operator: string
  playstyle: string
  notes: string
  createdAt: string
}

export interface SavedHud {
  id: string
  name: string
  fingers: DeviceProfile['fingers']
  buttonSize: number
  opacity: number
  layout: 'balanced' | 'movement' | 'aim'
  createdAt: string
}

export interface TrainingEntry {
  id: string
  date: string
  completed: string[]
  notes: string
}
