-- BLOOD STRIKE PRO HUB — Supabase starter schema
-- Apply in Supabase SQL Editor after creating a project.
-- All public catalogs only expose records that an administrator marks verified.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  avatar_url text,
  favourite_weapons text[] not null default '{}',
  role text not null default 'player' check (role in ('player', 'admin')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.guard_profile_role_change()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  if new.role is distinct from old.role
     and current_user not in ('postgres', 'supabase_admin')
     and not public.is_admin() then
    raise exception 'Only an administrator can change profile roles';
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_guard_role on public.profiles;
create trigger profiles_guard_role
before update of role on public.profiles
for each row execute function public.guard_profile_role_change();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username)
  values (new.id, nullif(trim(new.raw_user_meta_data ->> 'username'), ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.weapons (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  category text not null check (category in ('Assault Rifles', 'SMGs', 'LMGs', 'DMRs', 'Sniper Rifles', 'Shotguns')),
  image_url text,
  damage numeric,
  fire_rate numeric,
  effective_range text,
  recoil text,
  reload_time text,
  attachments text[] not null default '{}',
  strengths text,
  weaknesses text,
  playstyle text,
  suggested_scope text,
  community_rating numeric check (community_rating is null or (community_rating >= 0 and community_rating <= 5)),
  verified boolean not null default false,
  source_url text,
  source_notes text,
  updated_at timestamptz not null default now()
);

create table if not exists public.operators (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  role text,
  ability_description text,
  mobility integer check (mobility is null or mobility between 0 and 100),
  defense integer check (defense is null or defense between 0 and 100),
  utility integer check (utility is null or utility between 0 and 100),
  playstyle text,
  team_combinations text,
  image_url text,
  verified boolean not null default false,
  source_url text,
  source_notes text,
  updated_at timestamptz not null default now()
);

create table if not exists public.articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'Update',
  body text not null,
  author_id uuid references public.profiles(id) on delete set null,
  published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.media_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null check (category in ('Tutorial', 'Gameplay', 'Shorts', 'Review', 'News')),
  platform text,
  url text not null,
  creator text,
  thumbnail_url text,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  region text,
  format text,
  team_size integer check (team_size is null or team_size > 0),
  starts_at timestamptz,
  registration_closes_at timestamptz,
  status text not null default 'draft' check (status in ('draft', 'registration_open', 'registration_closed', 'in_progress', 'completed', 'cancelled')),
  rules_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.tournament_registrations (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  team_name text,
  created_at timestamptz not null default now(),
  unique (tournament_id, user_id)
);

create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 8 and 1000),
  status text not null default 'published' check (status in ('pending', 'published', 'hidden', 'removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.community_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  author_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  status text not null default 'published' check (status in ('pending', 'published', 'hidden', 'removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.community_likes (
  post_id uuid not null references public.community_posts(id) on delete cascade,
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  subject text not null check (char_length(subject) between 4 and 120),
  message text not null check (char_length(message) between 20 and 3000),
  status text not null default 'open' check (status in ('open', 'in_progress', 'closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.community_reports (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  reporter_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 500),
  status text not null default 'open' check (status in ('open', 'reviewed', 'dismissed', 'actioned')),
  created_at timestamptz not null default now(),
  unique (post_id, reporter_id)
);

-- Enable RLS on every exposed table.
alter table public.profiles enable row level security;
alter table public.weapons enable row level security;
alter table public.operators enable row level security;
alter table public.articles enable row level security;
alter table public.media_items enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_registrations enable row level security;
alter table public.community_posts enable row level security;
alter table public.community_comments enable row level security;
alter table public.community_likes enable row level security;
alter table public.community_reports enable row level security;
alter table public.support_messages enable row level security;

-- Profiles: public username/avatar visibility, owner-editable preferences, admin management.
drop policy if exists "profiles visible" on public.profiles;
create policy "profiles visible" on public.profiles for select using (true);
drop policy if exists "profiles owner update" on public.profiles;
create policy "profiles owner update" on public.profiles for update to authenticated
using (auth.uid() = id or public.is_admin())
with check (auth.uid() = id or public.is_admin());
drop policy if exists "profiles admin all" on public.profiles;
create policy "profiles admin all" on public.profiles for all to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Catalogs: only verified records are publicly readable; admins control all writes.
create policy "verified weapons readable" on public.weapons for select using (verified = true or public.is_admin());
create policy "admin manages weapons" on public.weapons for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "verified operators readable" on public.operators for select using (verified = true or public.is_admin());
create policy "admin manages operators" on public.operators for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "published articles readable" on public.articles for select using (published = true or public.is_admin());
create policy "admin manages articles" on public.articles for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "verified media readable" on public.media_items for select using (verified = true or public.is_admin());
create policy "admin manages media" on public.media_items for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "tournaments readable" on public.tournaments for select using (status <> 'draft' or public.is_admin());
create policy "admin manages tournaments" on public.tournaments for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Tournament registration: players can register themselves for open events, read own records.
create policy "registrations own read" on public.tournament_registrations for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "registrations own create" on public.tournament_registrations for insert to authenticated
with check (user_id = auth.uid() and exists (select 1 from public.tournaments t where t.id = tournament_id and t.status = 'registration_open'));
create policy "registrations own delete" on public.tournament_registrations for delete to authenticated
using (user_id = auth.uid() or public.is_admin());

-- Community: published content can be read; authors manage their own posts; admins moderate.
create policy "published posts readable" on public.community_posts for select using (status = 'published' or author_id = auth.uid() or public.is_admin());
create policy "authenticated create posts" on public.community_posts for insert to authenticated
with check (author_id = auth.uid());
create policy "author edit own posts" on public.community_posts for update to authenticated
using (author_id = auth.uid() or public.is_admin()) with check (author_id = auth.uid() or public.is_admin());
create policy "author delete own posts" on public.community_posts for delete to authenticated
using (author_id = auth.uid() or public.is_admin());

create policy "published comments readable" on public.community_comments for select using (status = 'published' or author_id = auth.uid() or public.is_admin());
create policy "authenticated create comments" on public.community_comments for insert to authenticated
with check (author_id = auth.uid() and exists (select 1 from public.community_posts p where p.id = post_id and p.status = 'published'));
create policy "comment author or admin update" on public.community_comments for update to authenticated
using (author_id = auth.uid() or public.is_admin()) with check (author_id = auth.uid() or public.is_admin());
create policy "comment author or admin delete" on public.community_comments for delete to authenticated
using (author_id = auth.uid() or public.is_admin());

create policy "likes visible" on public.community_likes for select using (true);
create policy "users manage own likes" on public.community_likes for all to authenticated
using (user_id = auth.uid() or public.is_admin()) with check (user_id = auth.uid() or public.is_admin());

create policy "reporter can create report" on public.community_reports for insert to authenticated
with check (reporter_id = auth.uid());
create policy "reporter or admin read reports" on public.community_reports for select to authenticated
using (reporter_id = auth.uid() or public.is_admin());
create policy "admin manages reports" on public.community_reports for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "user creates support message" on public.support_messages for insert to authenticated with check (user_id = auth.uid());
create policy "user reads own support messages" on public.support_messages for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "admin updates support messages" on public.support_messages for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Restrict browser-visible grants. In particular, role cannot be updated by ordinary clients.
grant usage on schema public to anon, authenticated;
grant select on public.profiles to anon, authenticated;
grant update (username, avatar_url, favourite_weapons) on public.profiles to authenticated;
grant select on public.weapons, public.operators, public.articles, public.media_items, public.tournaments to anon, authenticated;
grant insert, update, delete on public.weapons, public.operators, public.articles, public.media_items, public.tournaments to authenticated;
grant select, insert, delete on public.tournament_registrations to authenticated;
grant select, insert, update, delete on public.community_posts, public.community_comments to authenticated;
grant select, insert, delete on public.community_likes to authenticated;
grant select, insert, update on public.community_reports to authenticated;
grant select, insert, update on public.support_messages to authenticated;

-- Optional indexes for the primary feed queries.
create index if not exists articles_published_idx on public.articles (published, published_at desc);
create index if not exists media_verified_created_idx on public.media_items (verified, created_at desc);
create index if not exists tournament_start_idx on public.tournaments (starts_at);
create index if not exists community_posts_feed_idx on public.community_posts (status, created_at desc);
create index if not exists community_comments_post_idx on public.community_comments (post_id, created_at);

-- After signing up with your own account, run this once in the SQL Editor to promote it:
-- update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
