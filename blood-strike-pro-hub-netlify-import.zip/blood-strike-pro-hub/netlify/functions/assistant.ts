import type { Handler } from '@netlify/functions'

type ChatMessage = { role: 'user' | 'assistant'; content: string }

const SYSTEM_INSTRUCTIONS = `You are the Blood Strike Pro Hub assistant, an independent companion for NETEASE Blood Strike Mobile only. Be accurate, concise and practical. Do not give advice about other games unless needed to say the request is outside scope. Never invent current weapon stats, operator abilities, patch notes, event schedules, rankings, or scope availability. State when information needs confirmation in the current game build. Never promise zero recoil, guaranteed FPS, perfect sensitivity or competitive results. Treat sensitivity values as starting points and recommend small, controlled in-game tests. Give safe Android troubleshooting only; do not recommend rooting, disabling security protections, unknown booster apps, credential sharing or risky system edits. Do not request passwords or account secrets. If a question is unrelated to Blood Strike Mobile, briefly redirect to the supported scope.`

const requestCounts = new Map<string, { count: number; windowStart: number }>()
const WINDOW_MS = 60_000
const MAX_REQUESTS_PER_WINDOW = 12

function rateLimit(ip: string): boolean {
  const now = Date.now()
  const current = requestCounts.get(ip)
  if (!current || now - current.windowStart >= WINDOW_MS) {
    requestCounts.set(ip, { count: 1, windowStart: now })
    return true
  }
  if (current.count >= MAX_REQUESTS_PER_WINDOW) return false
  current.count += 1
  return true
}

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { Allow: 'POST', 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Method not allowed.' }) }
  }

  const apiKey = process.env.OPENAI_API_KEY
  const supabaseUrl = process.env.SUPABASE_URL
  const supabaseAnonKey = process.env.SUPABASE_ANON_KEY
  if (!apiKey || !supabaseUrl || !supabaseAnonKey) {
    return { statusCode: 503, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'AI service is not fully configured. Set OPENAI_API_KEY, SUPABASE_URL and SUPABASE_ANON_KEY in Netlify environment variables.' }) }
  }

  const authorization = event.headers.authorization || event.headers.Authorization || ''
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : ''
  if (!token) {
    return { statusCode: 401, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Sign in to your player account before using the AI assistant.' }) }
  }
  try {
    const authCheck = await fetch(`${supabaseUrl.replace(/\/$/, '')}/auth/v1/user`, {
      headers: { apikey: supabaseAnonKey, Authorization: `Bearer ${token}` },
    })
    if (!authCheck.ok) {
      return { statusCode: 401, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Your session could not be verified. Sign in again and retry.' }) }
    }
  } catch (error) {
    console.error('Supabase session verification failed:', error)
    return { statusCode: 503, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Could not verify your player session. Try again later.' }) }
  }

  const ip = event.headers['x-nf-client-connection-ip'] || event.headers['x-forwarded-for']?.split(',')[0]?.trim() || 'unknown'
  if (!rateLimit(ip)) {
    return { statusCode: 429, headers: { 'Content-Type': 'application/json', 'Retry-After': '60' }, body: JSON.stringify({ error: 'Too many requests. Wait a minute before trying again.' }) }
  }

  let parsed: { messages?: ChatMessage[] }
  try {
    parsed = JSON.parse(event.body || '{}') as { messages?: ChatMessage[] }
  } catch {
    return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Invalid JSON request.' }) }
  }

  if (!Array.isArray(parsed.messages) || parsed.messages.length < 1 || parsed.messages.length > 12) {
    return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Send between 1 and 12 chat messages.' }) }
  }

  const allowed = parsed.messages.every((message) =>
    message && (message.role === 'user' || message.role === 'assistant') &&
    typeof message.content === 'string' && message.content.trim().length > 0 && message.content.length <= 2_000,
  )
  if (!allowed) {
    return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Each message must contain a valid role and up to 2,000 characters.' }) }
  }

  const messages = parsed.messages.map((message) => ({ role: message.role, content: message.content.trim() }))
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-6-luna',
        instructions: SYSTEM_INSTRUCTIONS,
        input: messages,
        max_output_tokens: 700,
        store: false,
      }),
    })

    const payload = await response.json() as { output_text?: string; error?: { message?: string } }
    if (!response.ok) {
      console.error('OpenAI Responses API error:', response.status, payload.error?.message || 'No provider message')
      return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'The AI provider could not complete this request. Check the server function logs and model configuration.' }) }
    }
    const answer = payload.output_text?.trim()
    if (!answer) return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'The AI provider returned no text. Try a shorter question.' }) }
    return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ answer }) }
  } catch (error) {
    console.error('Assistant function network error:', error)
    return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Could not reach the AI provider. Try again later.' }) }
  }
}
